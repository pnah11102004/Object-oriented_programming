#ifndef DIEM_H
#define DIEM_H

#include <iostream>
using namespace std;

class DIEM {
public:
    DIEM();
    DIEM(float x, float y);
    ~DIEM();

    void set(float x, float y);
    float getX() const;
    float getY() const;
    void nhap();
    void xuat();

    friend istream& operator>>(istream& is, DIEM& p);
    friend ostream& operator<<(ostream& os, const DIEM& p);

private:
    float x;
    float y;
};

#endif // DIEM_H
