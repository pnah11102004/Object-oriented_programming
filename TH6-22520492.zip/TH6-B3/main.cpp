#include <iostream>
#include "DIEMMAU.h"

int main() {
    DIEMMAU p1, p2;

    std::cout << "Nhap diem p1:\n";
    std::cin >> p1;

    std::cout << "Nhap diem p2:\n";
    std::cin >> p2;

    std::cout << "Thong tin diem p1: " << p1 << std::endl;
    std::cout << "Thong tin diem p2: " << p2 << std::endl;

    if (p1.trungMau(p2)) {
        std::cout << "Hai diem co cung mau.\n";
    } else {
        std::cout << "Hai diem khong cung mau.\n";
    }

    return 0;
}
