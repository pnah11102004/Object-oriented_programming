#include "DIEM.h"

DIEM::DIEM() {
    x = 0.0f;
    y = 0.0f;
}

DIEM::DIEM(float x, float y) {
    this->x = x;
    this->y = y;
}

DIEM::~DIEM() {}

void DIEM::set(float x, float y) {
    this->x = x;
    this->y = y;
}

float DIEM::getX() const {
    return x;
}

float DIEM::getY() const {
    return y;
}

void DIEM::nhap() {
    std::cout << "Nhap toa do diem:\n";
    std::cout << "x = ";
    std::cin >> x;
    std::cout << "y = ";
    std::cin >> y;
}

void DIEM::xuat() {
    std::cout << "(" << x << ", " << y << ")";
}

std::istream& operator>>(std::istream& is, DIEM& p) {
    is >> p.x >> p.y;
    return is;
}

std::ostream& operator<<(std::ostream& os, const DIEM& p) {
    os << "(" << p.x << ", " << p.y << ")";
    return os;
}
