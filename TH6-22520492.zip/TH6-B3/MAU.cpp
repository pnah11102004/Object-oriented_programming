#include "MAU.h"

MAU::MAU() {
    red = 0;
    green = 0;
    blue = 0;
}

MAU::MAU(int red, int green, int blue) {
    this->red = red;
    this->green = green;
    this->blue = blue;
}

MAU::~MAU() {}

void MAU::setMau(int red, int green, int blue) {
    this->red = red;
    this->green = green;
    this->blue = blue;
}

int MAU::getRed() const {
    return red;
}

int MAU::getGreen() const {
    return green;
}

int MAU::getBlue() const {
    return blue;
}

bool MAU::trungMau(const MAU& other) const {
    return (red == other.red) && (green == other.green) && (blue == other.blue);
}

void MAU::nhap() {
    std::cout << "Nhap mau (RGB):\n";
    std::cout << "Red = ";
    std::cin >> red;
    std::cout << "Green = ";
    std::cin >> green;
    std::cout << "Blue = ";
    std::cin >> blue;
}

void MAU::xuat() {
    std::cout << " - Mau (RGB): (" << red << ", " << green << ", " << blue << ")";
}

std::istream& operator>>(std::istream& is, MAU& m) {
    is >> m.red >> m.green >> m.blue;
    return is;
}

std::ostream& operator<<(std::ostream& os, const MAU& m) {
    os << " - Mau (RGB): (" << m.red << ", " << m.green << ", " << m.blue << ")";
    return os;
}
