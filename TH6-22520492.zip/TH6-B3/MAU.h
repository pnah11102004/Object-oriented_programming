#ifndef MAU_H
#define MAU_H

#include <iostream>
using namespace std;
class MAU {
public:
    MAU();
    MAU(int red, int green, int blue);
    ~MAU();

    void setMau(int red, int green, int blue);
    int getRed() const;
    int getGreen() const;
    int getBlue() const;
    bool trungMau(const MAU& other) const;
    void nhap();
    void xuat();

    friend istream& operator>>(istream& is, MAU& m);
    friend ostream& operator<<(ostream& os, const MAU& m);

private:
    int red;
    int green;
    int blue;
};

#endif // MAU_H
