#ifndef DIEMMAU_H
#define DIEMMAU_H

#include "DIEM.h"
#include "MAU.h"

class DIEMMAU : public DIEM, public MAU {
public:
    DIEMMAU();
    DIEMMAU(float x, float y, int red, int green, int blue);
    ~DIEMMAU();

    friend istream& operator>>(istream& is, DIEMMAU& p);
    friend ostream& operator<<(ostream& os, const DIEMMAU& p);

private:

};

#endif // DIEMMAU_H
