#include "DIEMMAU.h"

DIEMMAU::DIEMMAU() : DIEM(), MAU() {}

DIEMMAU::DIEMMAU(float x, float y, int red, int green, int blue)
    : DIEM(x, y), MAU(red, green, blue) {}

DIEMMAU::~DIEMMAU() {}

std::istream& operator>>(std::istream& is, DIEMMAU& p) {
    is >> static_cast<DIEM&>(p);
    is >> static_cast<MAU&>(p);
    return is;
}

std::ostream& operator<<(std::ostream& os, const DIEMMAU& p) {
    os << static_cast<const DIEM&>(p);
    os << static_cast<const MAU&>(p);
    return os;
}
