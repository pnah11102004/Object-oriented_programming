#include "Diem3C.h"

Diem3C::Diem3C(float x, float y, float z) : x(x), y(y), z(z) {}

void Diem3C::setX(float x) {
    this->x = x;
}

void Diem3C::setY(float y) {
    this->y = y;
}

void Diem3C::setZ(float z) {
    this->z = z;
}

float Diem3C::getX() const {
    return x;
}

float Diem3C::getY() const {
    return y;
}

float Diem3C::getZ() const {
    return z;
}
