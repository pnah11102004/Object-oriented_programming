#ifndef DIEM3CMAU_H
#define DIEM3CMAU_H

#include "DIEM3C.h"
#include "MAU.h"

class Diem3CMau : public Diem3C, public Mau {
public:
    Diem3CMau(float x = 0.0f, float y = 0.0f, float z = 0.0f, int red = 0, int green = 0, int blue = 0);
    ~Diem3CMau();
    void setMau(int red, int green, int blue);
    void getMau(int& red, int& green, int& blue) const;
    bool trungMau(const Diem3CMau& other) const;
    void nhap();

    void xuat() const;
};

std::ostream& operator<<(std::ostream& os, const Diem3CMau& point);

#endif
