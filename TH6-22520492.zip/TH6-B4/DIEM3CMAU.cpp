#include "DIEM3CMAU.h"

Diem3CMau::Diem3CMau(float x, float y, float z, int red, int green, int blue) : Diem3C(x, y, z), Mau(red, green, blue) {}

Diem3CMau::~Diem3CMau() {}

void Diem3CMau::setMau(int red, int green, int blue) {
    Mau::setRed(red);
    Mau::setGreen(green);
    Mau::setBlue(blue);
}

void Diem3CMau::getMau(int& red, int& green, int& blue) const {
    red = Mau::getRed();
    green = Mau::getGreen();
    blue = Mau::getBlue();
}

bool Diem3CMau::trungMau(const Diem3CMau& other) const {
    int red, green, blue;
    other.getMau(red, green, blue);
    return (Mau::getRed() == red && Mau::getGreen() == green && Mau::getBlue() == blue);
}

void Diem3CMau::nhap() {
    cout << "Nhap toa do diem 3D: ";
    cin >> x >> y >> z;
    cout << "Nhap mau RGB: ";
    cin >> red >> green >> blue;
}

void Diem3CMau::xuat() const {
    cout << "Toa do diem 3D: (" << x << ", " << y << ", " << z << ")" << endl;
    cout << "Mau RGB: (" << red << ", " << green << ", " << blue << ")" << endl;
}

std::istream& operator>>(std::istream& is, Diem3CMau& point) {
    float x, y, z;
    int red, green, blue;
    is >> x >> y >> z >> red >> green >> blue;
    point.setX(x);
    point.setY(y);
    point.setZ(z);
    point.setMau(red, green, blue);
    return is;
}


std::ostream& operator<<(std::ostream& os, const Diem3CMau& point) {
    os << "Toa do diem 3D: (" << point.getX() << ", " << point.getY() << ", " << point.getZ() << ")" << std::endl;
    os << "Mau RGB: (" << point.getRed() << ", " << point.getGreen() << ", " << point.getBlue() << ")" << std::endl;
    return os;
}

