#ifndef MAU_H
#define MAU_H



class Mau {
protected:
    int red, green, blue;

public:
    Mau(int red = 0, int green = 0, int blue = 0);
    void setRed(int red);
    void setGreen(int green);
    void setBlue(int blue);
    int getRed() const;
    int getGreen() const;
    int getBlue() const;
};

#endif
