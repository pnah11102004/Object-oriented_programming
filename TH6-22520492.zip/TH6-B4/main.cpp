#include "DIEM3CMAU.h"
int main() {
    Diem3CMau point1;
    cout << "Nhap thong tin diem 1:" << endl;
    cin >> point1.nhap();
    cout << "Thong tin diem 1:" << endl;
    cout << point1.nhap();

    Diem3CMau point2;
    cout << "Nhap thong tin diem 2:" << endl;
    cin >> point2;
    cout << "Thong tin diem 2:" << endl;
    cout << point2;

    if (point1.trungMau(point2)) {
        cout << "Hai diem co cung mau" << endl;
    } else {
        cout << "Hai diem khong cung mau" << endl;
    }

    return 0;
}
