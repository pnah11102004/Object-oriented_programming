#ifndef DIEM3C_H_INCLUDED
#define DIEM3C_H_INCLUDED


#include <iostream>
using namespace std;


class Diem3C {
protected:
    float x, y, z;

public:
    Diem3C(float x = 0.0f, float y = 0.0f, float z = 0.0f);
    void setX(float x);
    void setY(float y);
    void setZ(float z);
    float getX() const;
    float getY() const;
    float getZ() const;
};




#endif // DIEM3C_H_INCLUDED
