#include "MAU.h"

Mau::Mau(int red, int green, int blue) : red(red), green(green), blue(blue) {}

void Mau::setRed(int red) {
    this->red = red;
}

void Mau::setGreen(int green) {
    this->green = green;
}

void Mau::setBlue(int blue) {
    this->blue = blue;
}

int Mau::getRed() const {
    return red;
}

int Mau::getGreen() const {
    return green;
}

int Mau::getBlue() const {
    return blue;
}
