#ifndef DIEM3C_H
#define DIEM3C_H
#include <iostream>
using namespace std;
class DIEM3C {
protected:
    float x, y, z;
public:
    DIEM3C(float x = 0, float y = 0, float z = 0);
    ~DIEM3C();
    void set(float x, float y, float z);
    float getX() const;
    float getY() const;
    float getZ() const;
    void nhap();
    void xuat();
    friend std::istream& operator>>(std::istream& is, DIEM3C& p);
    friend std::ostream& operator<<(std::ostream& os, const DIEM3C& p);
};

#endif
