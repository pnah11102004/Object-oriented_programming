#include <iostream>
#include "DIEMMAU3C.h"

using namespace std;

int main() {
    DIEMMAU3C p1, p2;

    cout << "Nhap diem p1:\n";
    cin >> p1;

    cout << "Nhap diem p2:\n";
    cin >> p2;

    cout << "Thong tin diem p1: " << p1 << endl;
    cout << "Thong tin diem p2: " << p2 << endl;

    if (p1.trungMau(p2)) {
        cout << "Hai diem co cung mau.\n";
    } else {
        cout << "Hai diem khong cung mau.\n";
    }

    return 0;
}
