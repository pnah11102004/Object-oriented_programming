#ifndef DIEMMAU3C_H
#define DIEMMAU3C_H

#include "DIEM3C.h"

class DIEMMAU3C : public DIEM3C {
private:
    int red, green, blue;
public:
    DIEMMAU3C(float x = 0, float y = 0, float z = 0, int red = 0, int green = 0, int blue = 0);
    ~DIEMMAU3C();
    void setMau(int red, int green, int blue);
    int getRed() const;
    int getGreen() const;
    int getBlue() const;
    bool trungMau(const DIEMMAU3C& other) const;
    void nhap();
    void xuat();
    friend istream& operator>>(istream& is, DIEMMAU3C& p);
    friend ostream& operator<<(ostream& os, const DIEMMAU3C& p);
};

#endif
