#include "DIEMMAU3C.h"

DIEMMAU3C::DIEMMAU3C(float x, float y, float z, int red, int green, int blue)
    : DIEM3C(x, y, z) {
    this->red = red;
    this->green = green;
    this->blue = blue;
}

DIEMMAU3C::~DIEMMAU3C() {}

void DIEMMAU3C::setMau(int red, int green, int blue) {
    this->red = red;
    this->green = green;
    this->blue = blue;
}

int DIEMMAU3C::getRed() const {
    return red;
}

int DIEMMAU3C::getGreen() const {
    return green;
}

int DIEMMAU3C::getBlue() const {
    return blue;
}

bool DIEMMAU3C::trungMau(const DIEMMAU3C& other) const {
    return (red == other.red) && (green == other.green) && (blue == other.blue);
}

void DIEMMAU3C::nhap() {
    DIEM3C::nhap();
    cout << "Nhap mau (RGB):\n";
    cout << "Red = ";
    cin >> red;
    cout << "Green = ";
    cin >> green;
    cout << "Blue = ";
    cin >> blue;
}

void DIEMMAU3C::xuat() {
    DIEM3C::xuat();
    cout << " - Mau (RGB): (" << red << ", " << green << ", " << blue << ")";
}

istream& operator>>(istream& is, DIEMMAU3C& p) {
    is >> static_cast<DIEM3C&>(p);
    is >> p.red >> p.green >> p.blue;
    return is;
}

ostream& operator<<(ostream& os, const DIEMMAU3C& p) {
    os << static_cast<const DIEM3C&>(p);
    os << " - Mau (RGB): (" << p.red << ", " << p.green << ", " << p.blue << ")";
    return os;
}
