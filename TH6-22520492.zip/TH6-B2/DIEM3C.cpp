#include "DIEM3C.h"

DIEM3C::DIEM3C(float x, float y, float z) {
    this->x = x;
    this->y = y;
    this->z = z;
}

DIEM3C::~DIEM3C() {}

void DIEM3C::set(float x, float y, float z) {
    this->x = x;
    this->y = y;
    this->z = z;
}

float DIEM3C::getX() const {
    return x;
}

float DIEM3C::getY() const {
    return y;
}

float DIEM3C::getZ() const {
    return z;
}

void DIEM3C::nhap() {
    cout << "Nhap toa do diem:\n";
    cout << "x = ";
    cin >> x;
    cout << "y = ";
    cin >> y;
    cout << "z = ";
    cin >> z;
}

void DIEM3C::xuat() {
    std::cout << "(" << x << ", " << y << ", " << z << ")";
}

istream& operator>>(istream& is, DIEM3C& p) {
    is >> p.x >> p.y >> p.z;
    return is;
}

ostream& operator<<(ostream& os, const DIEM3C& p) {
    os << "(" << p.x << ", " << p.y << ", " << p.z << ")";
    return os;
}
