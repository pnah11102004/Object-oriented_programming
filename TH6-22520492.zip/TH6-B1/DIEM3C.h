#ifndef DIEM3C_H_INCLUDED
#define DIEM3C_H_INCLUDED
#include<iostream>

#include "DIEM.h"
using namespace std;
class DIEM3C : public DIEM {
private:
    float z;

public:
    DIEM3C();
    DIEM3C(float x, float y, float z);
    ~DIEM3C();

    void setZ(float z);
    float getZ() const;
    bool trungDiem(const DIEM3C& other) const;
    void diChuyen(float dx, float dy, float dz);
    float khoangCach(const DIEM3C& other) const;
    DIEM3C doiXung() const;

    void nhap();
    void xuat();
    float chuViTamGiac(const DIEM3C& b, const DIEM3C& c) const;
    float dienTichTamGiac(const DIEM3C& b, const DIEM3C& c) const;

    friend istream& operator>>(istream& is, DIEM3C& point);
    friend ostream& operator<<(ostream& os, const DIEM3C& point);
};

istream& operator>>(istream& is, DIEM3C& point);
ostream& operator<<(ostream& os, const DIEM3C& point);



#endif // DIEM3C_H_INCLUDED
