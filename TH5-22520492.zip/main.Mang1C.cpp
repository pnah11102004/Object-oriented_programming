#include <iostream>
#include"Mang1C.h"
int main()
{
    Mang1C m1c;
    int chon;
    do
    {

        cout << "------------CHUONG TRINH THAO TAC MANG 1 CHIEU-------------\n";
		cout << "1.Nhap mang.\n";
		cout << "2.Xuat mang.\n";
		cout << "3.Liet ke cac gia tri la so nguyen to co trong mang.\n";
		cout << "4.Dem so luong phan tu la so chinh phuong trong mang.\n";
		cout << "5.Tinh tong gia tri cac phan tu la so hoan thien trong mang.\n";
		cout << "6.Tinh TB cong gia tri cac phan tu la so doi xung.\n";
		cout << "7.Kiem tra mang co toan phan tu le hay khong?\n";
		cout << "8.Tim gia tri phan tu chan be nhat trong mang.\n";
		cout << "9.Sap xep mang tang dan.\n";
		cout << "10.Sap xep mang giam dan.\n";
		cout << "11.Xoa phan tu trong mang.\n";
		cout << "12.Them phan tu trong mang.\n";
		cout << "13.Tim kiem phan tu trong mang.\n";
		cout << "14.Phat sinh tu dong gia tri cac phan tu trong mang.\n";
		cout << "0.Thoat Chuong Trinh!\n";
		cout << "-----------------------------------------------------------\n";
		cout << "Ban chon: ";
		cin >> chon;
		switch (chon)
		{
		case 0: cout << "Dang thoat chuong trinh... \n"; break;
		case 1: cin >> m1c; break;
		case 2:
		    m1c.PhatSinh();
		    cout << "Mang phat sinh la: "<<endl<<m1c;
		     break;
		case 3: cout << m1c;
			break;
		case 4:
		    if(m1c.GetN()>0)
                m1c.LietKeSNT();
                else
                cout<<"Mang rong"<<endl;
            break;
		case 5:
		    {
		        if(m1c.GetN()>0)
                {
                    int demscp=m1c.DemSCP();
                    if(demscp>0)
                        cout<<"Co "<<demscp<<" phan tu la SCP trong mang. "<<endl;
                    else
                        cout<<"Mang khong co phan tu la SCP"<<endl;
                }
                else
                    cout<<"Mang rong"<<endl;
		    }
		    	break;
		case 6:
		     {
		        if(m1c.GetN()>0)
                {
                    int tongsht=m1c.TinhTongSHT();
                    if(tongsht>0)
                        cout<<"Tong gia tri cac phan tu la SHT trong mang la: "<<tongsht<<endl;
                    else
                        cout<<"Mang khong co phan tu la SHT"<<endl;
                }
                else
                    cout<<"Mang rong"<<endl;
		    }
		    	break;
		case 7:
		     {
		        if(m1c.GetN()>0)
                {
                    double tbcongsdx=m1c.TinhTBCongSDX();
                    if(tbcongsdx>0)
                        cout<<"TBC gia tri cac phan tu la SDX trong mang la:  "<<tbcongsdx<<endl;
                    else
                        cout<<"Mang khong co phan tu la SDX"<<endl;
                }
                else
                    cout<<"Mang rong"<<endl;
		    }
		    	break;
		case 8:
		        if(m1c.GetN()>0)
                {
                    if(m1c.KiemTraMangLe())
                        cout<<"Mang toan phan tu le. "<<endl;
                    else
                        cout<<"Mang co chua phan tu chan."<<endl;
                }
                else
                    cout<<"Mang rong"<<endl;

		    	break;
		case 9:
		    if(m1c.GetN()>0)
                m1c.TimChanBeNhat();
            else
                cout<<"Mang rong"<<endl;
			break;
		case 10:
		        if(m1c.GetN()>0)
                {
                    m1c.SapXepMangTang();
                        cout<<"Mang sau khi sap xep tang dan la: "<<m1c<<endl;

                }
                else
                    cout<<"Mang rong"<<endl;

		    	break;
		case 11: int p;
			 {
		        if(m1c.GetN()>0)
                {
                    int vtxoa;
                    do
                    {
                        cout<<"Nhap vi tri phan tu muon xoa tu 0 den "<<m1c.GetN()-1<<": ";
                        cin>>vtxoa;
                    } while(vtxoa<0||vtxoa>=m1c.GetN());
                    m1c.XoaTaiVT(vtxoa);
                    cout<<"Mang sau khi xoa phan tu tai vi tri thu "<<vtxoa<<" la: "<<m1c<<endl;
                }
                else
                    cout<<"Mang rong"<<endl;
		    }
		    	break;
		case 12:
		     {
                    int vtthem,gtthem;
                    do
                    {
                        cout<<"Nhap vi tri phan tu muon them tu 0 den "<<m1c.GetN()<<": ";
                        cin>>vtthem;
                    } while(vtthem<0||vtthem>=m1c.GetN());
                    cout<<"Nhap gia tri phan tu muon them: ";
                    cin>>gtthem;
                    m1c.ThemTaiVT(vtthem,gtthem);
                    cout<<"Mang sau khi them phan tu a["<<vtthem<<"]="<<gtthem<<" la:\n"<<m1c;
                }

		    	break;
		case 13:
			m1c.~Mang1C();
			cout<<"Mang sau khi xoa la: "<<m1c;
			break;
		case 14:
			{
		        if(m1c.GetN()>0)
                {
                    int gttim,vttim;
                    cout<<"Nhap gia tri phan tu can tim: ";
                    cin>>gttim;
                    vttim=m1c.TimKiemTuyenTinh(gttim);
                    if(vttim!=-1)
                        cout<<"Tim thay phan tu co gia tri "<<gttim<<" tai vi tri thu "<<vttim<<endl;
                    else
                        cout<<"Khong tim thay"<<endl;
                }
                else
                    cout<<"Mang rong"<<endl;
		    }
		    	break;
        case 15:
            {
		        if(m1c.GetN()>0)
                {
                    m1c.SapXepMangTang();
                    cout<<"Mang sap xep tang dan la:\n"<<m1c;
                    int gttim,vttim;
                    cout<<"Nhap gia tri phan tu can tim: ";
                    cin>>gttim;
                    vttim=m1c.TimKiemNhiPhan(gttim);
                    if(vttim!=-1)
                        cout<<"Tim thay phan tu co gia tri "<<gttim<<" tai vi tri thu "<<vttim<<endl;
                    else
                        cout<<"Khong tim thay."<<endl;
                }
                else
                    cout<<"Mang rong"<<endl;
		    }
		    	break;
        default:
            cout<<"Ban chon sai.Moi chon lai."<<endl;
            break;
		}
    }while (chon!=0);
}
