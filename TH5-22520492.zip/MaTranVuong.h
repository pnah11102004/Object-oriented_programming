#ifndef MATRANVUONG_H_INCLUDED
#define MATRANVUONG_H_INCLUDED
#include<iostream>
using namespace std;
class MaTranVuong {
private:
    int n;
    int** p;

public:
    MaTranVuong();
    MaTranVuong(int n);
    MaTranVuong(const MaTranVuong& other);
    ~MaTranVuong();

    void NhapMaTran();
    void XuatMaTran();
    void LietKeLeTrenDuongCheoChinh();
    int DemSoKySoCuoiLa3TrenDuongCheoPhu();
    bool TonTaiSoAmTrenNuaMangTrenDuongCheoChinh();
    int TimPhanTuChanDauTienDuoiDuongCheoPhu();
    void SapXepGiamDanDuongCheoPhu();
};


#endif // MATRANVUONG_H_INCLUDED
