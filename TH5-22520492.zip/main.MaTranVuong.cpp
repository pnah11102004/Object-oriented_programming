#include "MaTranVuong.h"

int main() {
    int n;
    cout << "Nhap cap ma tran: ";
    cin >> n;

    MaTranVuong mtv(n);

    mtv.NhapMaTran();
    mtv.XuatMaTran();
    mtv.LietKeLeTrenDuongCheoChinh();

    int count = mtv.DemSoKySoCuoiLa3TrenDuongCheoPhu();
    cout << "So luong phan tu co ky so cuoi la 3 tren duong cheo phu: " << count << endl;

    bool tonTaiSoAm = mtv.TonTaiSoAmTrenNuaMangTrenDuongCheoChinh();
    if (tonTaiSoAm) {
        cout << "Ton tai phan tu am tren nua mang tren duong cheo chinh.\n";
    } else {
        cout << "Khong ton tai phan tu am tren nua mang tren duong cheo chinh.\n";
    }

    int phanTuChan = mtv.TimPhanTuChanDauTienDuoiDuongCheoPhu();
    if (phanTuChan != -1) {
        cout << "Phan tu chan dau tien duoi duong cheo phu: " << phanTuChan << endl;
    } else {
        cout << "Khong ton tai phan tu chan duoi duong cheo phu.\n";
    }

    mtv.SapXepGiamDanDuongCheoPhu();
    mtv.XuatMaTran();

    return 0;
}

