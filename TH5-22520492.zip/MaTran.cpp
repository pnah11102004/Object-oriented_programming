#include "MaTran.h"
#include <iostream>
#include <cmath>

using namespace std;

MaTran::MaTran() {
    sd = 0;
    sc = 0;
    p = nullptr;
}

MaTran::MaTran(int d, int c) {
    sd = d;
    sc = c;
    p = new int*[sd];
    for (int i = 0; i < sd; i++) {
        p[i] = new int[sc];
    }
}

MaTran::MaTran(const MaTran& other) {
    sd = other.sd;
    sc = other.sc;
    p = new int*[sd];
    for (int i = 0; i < sd; i++) {
        p[i] = new int[sc];
        for (int j = 0; j < sc; j++) {
            p[i][j] = other.p[i][j];
        }
    }
}

MaTran::~MaTran() {
    if (p != nullptr) {
        for (int i = 0; i < sd; i++) {
            delete[] p[i];
        }
        delete[] p;
    }
}

void MaTran::Nhap() {
    cout << "Nhap gia tri cac phan tu ma tran:\n";
    for (int i = 0; i < sd; i++) {
        for (int j = 0; j < sc; j++) {
            cout << "Phan tu thu [" << i << "][" << j << "]: ";
            cin >> p[i][j];
        }
    }
}

void MaTran::Xuat() {
    cout << "Gia tri cac phan tu ma tran:\n";
    for (int i = 0; i < sd; i++) {
        for (int j = 0; j < sc; j++) {
            cout << p[i][j] << " ";
        }
        cout << endl;
    }
}

bool LaSoNguyenTo(int n) {
    if (n < 2) {
        return false;
    }
    for (int i = 2; i <= sqrt(n); i++) {
        if (n % i == 0) {
            return false;
        }
    }
    return true;
}

void MaTran::LietKeSoNguyenTo() {
    cout << "Cac phan tu la so nguyen to trong ma tran:\n";
    for (int i = 0; i < sd; i++) {
        for (int j = 0; j < sc; j++) {
            if (LaSoNguyenTo(p[i][j])) {
                cout << p[i][j] << " ";
            }
        }
    }
    cout << endl;
}

bool LaSoChinhPhuong(int n) {
    int sq = sqrt(n);
    return sq * sq == n;
}

int MaTran::DemSoChinhPhuong() {
    int count = 0;
    for (int i = 0; i < sd; i++) {
        for (int j = 0; j < sc; j++) {
            if (LaSoChinhPhuong(p[i][j])) {
                count++;
            }
        }
    }
    return count;
}

bool LaSoHoanThien(int n) {
    int sum = 1;
    for (int i = 2; i * i <= n; i++) {
        if (n % i == 0) {
            sum += i;
            if (i * i != n) {
                sum += n / i;
            }
        }
    }
    return sum == n;
}

int MaTran::TongSoHoanThienTrenDong(int k) {
    int sum = 0;
    if (k >= 0 && k < sd) {
        for (int j = 0; j < sc; j++) {
            if (LaSoHoanThien(p[k][j])) {
                sum += p[k][j];
            }
        }
    }
    return sum;
}

bool LaSoDoiXung(int n) {
    int temp = n;
    int reversed = 0;
    while (temp != 0) {
        reversed = reversed * 10 + temp % 10;
        temp /= 10;
    }
    return n == reversed;
}

double MaTran::TrungBinhCongSoDoiXungTrenCot(int k) {
    int count = 0;
    double sum = 0;
    if (k >= 0 && k < sc) {
        for (int i = 0; i < sd; i++) {
            if (LaSoDoiXung(p[i][k])) {
                sum += p[i][k];
                count++;
            }
        }
    }
    return (count > 0) ? (sum / count) : 0;
}

void MaTran::SapXepTangDanTrenDong(int k) {
    if (k >= 0 && k < sd) {
        for (int j = 0; j < sc - 1; j++) {
            for (int i = 0; i < sc - j - 1; i++) {
                if (p[k][i] > p[k][i + 1]) {
                    int temp = p[k][i];
                    p[k][i] = p[k][i + 1];
                    p[k][i + 1] = temp;
                }
            }
        }
    }
}
