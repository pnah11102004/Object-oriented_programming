#pragma once
#ifndef _Mang1C
#define _Mang1C
#include<iostream>
#include<iomanip>
using namespace std;
class Mang1C
{
private:
    int* a;
    int n;
    bool KiemTraSNT(int);
    bool KiemTraSCP(int);
    bool KiemTraSHT(int);
    bool KiemTraSDX(int);
public:
    ~Mang1C();
    Mang1C(int =0,int =0);
    Mang1C(const Mang1C&);
    Mang1C& operator=(const Mang1C&);
    int GetN();
    int* GetA();
    friend istream& operator>>(istream&, Mang1C&);
    friend ostream& operator<<(ostream&, const Mang1C&);
    void PhatSinh();
    void LietKeSNT();
    int DemSCP();
    int TinhTongSHT();
    double TinhTBCongSDX();
    bool KiemTraMangLe();
    void TimChanBeNhat();
    void SapXepMangTang();
    void XoaTaiVT(int);
    void ThemTaiVT(int,int);
    int TimKiemTuyenTinh(int);
    int TimKiemNhiPhan(int);

};
#endif // _Mang1C
