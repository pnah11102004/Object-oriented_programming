#include "MaTran.h"

int main() {
    int d, c;
    cout << "Nhap so dong cua ma tran: ";
    cin >> d;
    cout << "Nhap so cot cua ma tran: ";
    cin >> c;

    MaTran matrix(d, c);
    matrix.Nhap();

    cout << "Ma tran vua nhap:\n";
    matrix.Xuat();

    cout << "Cac phan tu la so nguyen to:\n";
    matrix.LietKeSoNguyenTo();

    int count = matrix.DemSoChinhPhuong();
    cout << "So luong phan tu la so chinh phuong: " << count << endl;

    int k;
    cout << "Nhap dong k de tinh tong cac so hoan thien: ";
    cin >> k;
    int sumHoanThien = matrix.TongSoHoanThienTrenDong(k);
    cout << "Tong cac so hoan thien tren dong " << k << ": " << sumHoanThien << endl;

    cout << "Nhap cot k de tinh trung binh cong cac so doi xung: ";
    cin >> k;
    double avgDoiXung = matrix.TrungBinhCongSoDoiXungTrenCot(k);
    cout << "Trung binh cong cac so doi xung tren cot " << k << ": " << avgDoiXung << endl;

    cout << "Nhap dong k de sap xep tang dan: ";
    cin >> k;
    matrix.SapXepTangDanTrenDong(k);
    cout << "Ma tran sau khi sap xep tang dan tren dong " << k << ":\n";
    matrix.Xuat();

    return 0;
}
