#include "MaTranVuong.h"
#include <iostream>

MaTranVuong::MaTranVuong() {
    n = 0;
    p = nullptr;
}

MaTranVuong::MaTranVuong(int n) {
    this->n = n;
    p = new int*[n];
    for (int i = 0; i < n; i++) {
        p[i] = new int[n];
    }
}

MaTranVuong::MaTranVuong(const MaTranVuong& other) {
    n = other.n;
    p = new int*[n];
    for (int i = 0; i < n; i++) {
        p[i] = new int[n];
        for (int j = 0; j < n; j++) {
            p[i][j] = other.p[i][j];
        }
    }
}

MaTranVuong::~MaTranVuong() {
    for (int i = 0; i < n; i++) {
        delete[] p[i];
    }
    delete[] p;
}

void MaTranVuong::NhapMaTran() {
    cout << "Nhap gia tri cac phan tu cua ma tran:\n";
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            cout << "Nhap phan tu thu (" << i << ", " << j << "): ";
            cin >> p[i][j];
        }
    }
}

void MaTranVuong::XuatMaTran() {
    cout << "Gia tri cac phan tu cua ma tran:\n";
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            cout << p[i][j] << " ";
        }
        cout << endl;
    }
}

void MaTranVuong::LietKeLeTrenDuongCheoChinh() {
    cout << "Cac phan tu le tren duong cheo chinh:\n";
    for (int i = 0; i < n; i++) {
        if (p[i][i] % 2 != 0) {
            cout << p[i][i] << " ";
        }
    }
    cout << endl;
}

int MaTranVuong::DemSoKySoCuoiLa3TrenDuongCheoPhu() {
    int count = 0;
    for (int i = 0; i < n; i++) {
        if (p[i][n - i - 1] % 10 == 3) {
            count++;
        }
    }
    return count;
}

bool MaTranVuong::TonTaiSoAmTrenNuaMangTrenDuongCheoChinh() {
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < i; j++) {
            if (p[i][j] < 0) {
                return true;
            }
        }
    }
    return false;
}

int MaTranVuong::TimPhanTuChanDauTienDuoiDuongCheoPhu() {
    for (int i = n - 1; i > 0; i--) {
        for (int j = n - i; j < n; j++) {
            if (p[i][j] % 2 == 0) {
                return p[i][j];
            }
        }
    }
    return -1; // Khong tim thay phan tu chan
}

void MaTranVuong::SapXepGiamDanDuongCheoPhu() {
    for (int i = 0; i < n - 1; i++) {
        for (int j = 0; j < n - i - 1; j++) {
            if (p[i][n - i - 1] < p[i + 1][n - i - 2]) {
                int temp = p[i][n - i - 1];
                p[i][n - i - 1] = p[i + 1][n - i - 2];
                p[i + 1][n - i - 2] = temp;
            }
        }
    }
}
