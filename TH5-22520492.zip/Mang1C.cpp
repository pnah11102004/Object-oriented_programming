#include"Mang1C.h"
#include<cmath>
Mang1C::~Mang1C()
{
    if(a!=NULL)
    {
        delete[]a;
        a=NULL;
        n=0;
    }
}
Mang1C::Mang1C(int n,int m)
{
    if(n==0)
    {
        this->n=0;
        a=NULL;
    }
    else
    {
        while(n<=0)
        {
            cout<<"Nhap la so phan tu mang > 0: ";
            cin>>n;
        }
        this->n=n;
        a=new int[this->n];
        for(int i=0;i<this->n;i++)
            a[i]=m;
    }
}
Mang1C::Mang1C(const Mang1C& m)
{
    if(m.n==0)
    {
        this->n=0;
        a=NULL;
    }
    else
    {
        n=m.n;
        a=new int[n];
        for (int i=0;i<n;i++)
            a[i]=m.a[i];
    }
}
Mang1C& Mang1C::operator=(const Mang1C& m)
{
    if(m.n==0)
    {
        this->n=0;
        a=NULL;
    }
    else
    {
        n=m.n;
        a=new int[n];
        for (int i=0;i<n;i++)
            a[i]=m.a[i];
    }
    return *this;
}
int Mang1C::GetN()
{
    return n;
}
int* Mang1C::GetA()
{
    return a;
}
istream& operator>>(istream& is, Mang1C& m)
{
    if(m.a!=NULL)
        m.~Mang1C();
    do {
        cout<<"Nhap so phan tu mang > 0: ";
        is>>m.n;
    } while (m.n<=0);
    m.a = new int[m.n];
    for(int i=0;i<m.n;i++)
    {
        cout<<"a["<<i<<"]= ";
        is>>m.a[i];
    }
    return is;
}
ostream& operator<<(ostream& os, const Mang1C& m)
{
    if(m.a==NULL)
        os<<"Mang rong"<<endl;
    else
    {
        for(int i=0;i<m.n;i++)
            os<<m.a[i]<<"\t";
        os<<endl;
    }
    return os;
}
void Mang1C::PhatSinh()
{
    if(a!=NULL)
        this->~Mang1C();
    do
    {
        cout<<"Nhap so phan tu mang > 0: ";
        cin>>n;
    }  while(n<=0);
    a=new int[n];
    int mi,ma;
    cout<<"Nhap mien gia tri phat sinh: ";
    cin>>mi>>ma;
    srand(time(0));
    for(int i=0;i<n;i++)
        a[i]=mi+rand()%(ma-mi+1);
}
bool Mang1C::KiemTraSNT(int n)
{
 bool snt=true;
 if(n<2)
        snt=false;
 else
    for(int i=2;i<=n/2;i++)
    if(n%i==0)
 {
     snt=false;
     break;
 }
 return snt;
}
bool Mang1C::KiemTraSCP(int n)
{
    bool scp=false;
    if(n<1)
        scp=false;
    else
        if(sqrt(n)==(int)sqrt(n))
            scp=true;
    return scp;
}
bool Mang1C::KiemTraSHT(int n)
{
    bool sht;
    if(n<6)
        sht=false;
    else
    {
        int tongus=0;
        for(int i=1;i<=n/2;i++)
            if(n%i==0)
            tongus+=i;
        sht=tongus==n?true:false;

    }
    return sht;
}
bool Mang1C::KiemTraSDX(int n)
{
    bool sdx;
    if(n<1)
        sdx=false;
    else
    {
        int m=n,dv,dao=0;
        while(m>0)
        {
            dv=m%10;
            dao=dao*10+dv;
            m/=10;
        }
        sdx=dao==n?true:false;
    }
    return sdx;
}
void Mang1C::LietKeSNT()
{
    int demsnt=0;
    for(int i=0;i<n;i++)
        if(KiemTraSNT(a[i]))
    {
        cout<<a[i]<<"\t";
        demsnt++;
    }
    cout<<endl;
    if(demsnt==0)
        cout<<"Mang khong chua phan tu la SNT"<<endl;
}
int Mang1C::DemSCP()
{
    int demscp=0;
    for(int i=0;i<n;i++)
        if(KiemTraSCP(a[i]))
        demscp++;
    return demscp;
}
int Mang1C::TinhTongSHT()
{
    int tongsht=0;
    for(int i=0;i<n;i++)
        if(KiemTraSHT(a[i]))
        tongsht+=a[i];
    return tongsht;
}
double Mang1C::TinhTBCongSDX()
{
    double tongsdx=0,demsdx=0;
    for(int i=0;i<n;i++)
        if(KiemTraSDX(a[i]))
    {
        tongsdx+=a[i];
        demsdx++;
    }
    return demsdx>0?tongsdx/demsdx:0;
}
bool Mang1C::KiemTraMangLe()
{
    bool mangle=true;
    for(int i=0;i<n;i++)
        if(a[i]%2==0)
    {
        mangle=false;
        break;
    }
    return mangle;
}
void Mang1C::TimChanBeNhat()
{
    int vtChanDau=-1,gtChanBeNhat;
    for(int i=0;i<n;i++)
        if(a[i]%2==0)
    {
        vtChanDau=i;
        gtChanBeNhat=a[i];
        break;
    }
    if(vtChanDau!=-1)
    {
        for(int i=vtChanDau+1;i<n;i++)
            if(a[i]%2==0&&a[i]<gtChanBeNhat)
        {
            vtChanDau=i;
            gtChanBeNhat=a[i];
        }
        cout<<"Phan tu chan be nhat trong mang la a["<<vtChanDau<<"]="<<gtChanBeNhat<<endl;

    }
    else
        cout<<"Mang khong co phan tu chan "<<endl;
}
void Mang1C::SapXepMangTang()
{
    int tam;
    for(int i=0;i<n-1;i++)
        for(int j=i+1;j<n;j++)
        if(a[i]>a[j])
    {
        tam=a[i];
        a[i]=a[j];
        a[j]=tam;
    }
}
void Mang1C::XoaTaiVT(int vt)
{
    Mang1C mMoi(n-1);
    for(int i=0;i<vt;i++)
        mMoi.a[i]=a[i];
    for(int i=vt;i<n-1;i++)
        mMoi.a[i]=a[i+1];
    this->~Mang1C();
    *this=mMoi;
    mMoi.~Mang1C();
}
void Mang1C::ThemTaiVT(int vt,int gt)
{
    Mang1C mMoi(n+1);
    for(int i=0;i<vt;i++)
        mMoi.a[i]=a[i];
    mMoi.a[vt]=gt;
    for(int i=vt+1;i<=n;i++)
        mMoi.a[i]=a[i-1];
    this->~Mang1C();
    *this = mMoi;
    mMoi.~Mang1C();
}
int Mang1C::TimKiemTuyenTinh(int gt)
{
    int timthay=-1;
    for(int i=0;i<n;i++)
        if(a[i]==gt)
    {
        timthay=i;
        break;
    }
    return timthay;
}
int Mang1C::TimKiemNhiPhan(int gt)
{
    int dau=0,cuoi=n-1,giua;
    int timthay=-1;
    while(dau<=cuoi)
    {
        giua=(dau+cuoi)/2;
        if(a[giua]==gt)
        {

        timthay=giua;
        break;
    }
    if(gt<a[giua])
        cuoi=giua-1;
    else
        dau=giua+1;
    }return timthay;
}
