#ifndef MATRAN_H_INCLUDED
#define MATRAN_H_INCLUDED

#include<iostream>
using namespace std;
class MaTran {
private:
    int sd; // số dòng
    int sc; // số cột
    int** p; // con trỏ tới vùng nhớ động chứa các phần tử ma trận

public:
    MaTran();
    MaTran(int d, int c);
    MaTran(const MaTran& other);
    ~MaTran();

    void Nhap();
    void Xuat();
    void LietKeSoNguyenTo();
    int DemSoChinhPhuong();
    int TongSoHoanThienTrenDong(int k);
    double TrungBinhCongSoDoiXungTrenCot(int k);
    void SapXepTangDanTrenDong(int k);
};



#endif // MATRAN_H_INCLUDED
