#include <iostream>

#include "TH2_Bai2_SOPHUC.cpp"
using namespace std;
int main()
{

    SOPHUC sp1, sp2, kq;
    cout << "Nhap so phuc thu nhat: \n";
    sp1.Nhap();
    cout << "So phuc thu nhat la: ";
    sp1.Xuat();

    cout << "Nhap so phuc thu hai: \n";
    sp2.Nhap();
    cout << "So phuc thu hai la: ";
    sp2.Xuat();

    cout << "Tong hai so phuc la: ";
    kq = sp1.Cong (sp2);
    kq.Xuat();
    cout << "\nHieu hai so phuc la: ";
    kq = sp1.Tru (sp2);
    kq.Xuat();
    cout << "\nTich hai so phuc la: ";
    kq = sp1.Nhan(sp2);
    kq.Xuat();
    cout << "\nThuong hai so phuc la: ";
    kq= sp1.Chia(sp2);
    kq.Xuat();


    return 0;
}
