#ifndef TH2_Them_Bai5_hocsinh_H_INCLUDED
#define TH2_Them_Bai5_hocsinh_H_INCLUDED

#include <string>
using namespace std;
class HocSinh {
private:
    string tenHS;
    float diemVan;
    float diemToan;
public:
    HocSinh();
    HocSinh(string ten, float van, float toan);
    void nhap();
    void xuat();
    float tinhDTB();
    string xepLoai();
};


#endif // HOCSINH_H_INCLUDED
