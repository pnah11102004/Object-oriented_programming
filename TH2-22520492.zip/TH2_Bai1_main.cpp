#include <iostream>
#include "TH2_Bai1_PhanSo.h"
#include "TH2_Bai1_PhanSo.cpp"
using namespace std;
int main() {
PhanSo a,b;
// Nhập giá trị cho hai phân số
cout << "Nhap phan so a:\n";
a.nhap();
cout << "Nhap phan so b:\n";
b.nhap();

// Tính toán và in ra kết quả các phép toán cộng, trừ, nhân, chia hai phân số
cout << "a + b = ";
a.cong(b).xuat();
cout << endl;

cout << "a - b = ";
a.tru(b).xuat();
cout << endl;

cout << "a * b = ";
a.nhan(b).xuat();
cout << endl;

cout << "a / b = ";
a.chia(b).xuat();
cout << endl;

return 0;

}
