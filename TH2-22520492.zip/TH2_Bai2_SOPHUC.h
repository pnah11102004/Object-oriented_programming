#ifndef TH2_Bai2_SOPHUC_H_INCLUDED
#define TH2_Bai2_SOPHUC_INCLUDED
class SOPHUC
{
private:
    double thuc;
    double ao;

public:

  SOPHUC(double = 0 , double  = 0 );


    double Getthuc();
    double Getao();
    void Setthuc(double);
    void Setao(double);
    void Setsophuc(double, double);
    void Nhap();
    void Xuat();

    SOPHUC Cong(const SOPHUC& );
    SOPHUC Tru(const SOPHUC& );
    SOPHUC Nhan(const SOPHUC& );
    SOPHUC Chia(const SOPHUC& );

};


#endif // SOPHUC_H_INCLUDED
