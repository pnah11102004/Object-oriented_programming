﻿/*Xây dựng lớp Candidate (Thí sinh) gồm các thuộc tính: mã, tên, ngày tháng năm
sinh, điểm thi Toán, Văn, Anh và các phương thức cần thiết.
Xây dựng lớp TestCandidate để kiểm tra lớp trên:
- Nhập vào n thí sinh (n do người dùng nhập)
- In ra thông tin về các thí sinh có tổng điểm lớn hơn 15

+Input: Thông tin n  thí sinh, id, tên, ngày sinh, điểm các môn toán văn anh;
+Output: Thông tin các thí sinh có tổng điểm lớn hơn 15.
+GT:    -Nhập dữ liệu
        -Khai báo biến, kiểu dữ liệu và các phương thức hỗ trọ
        -Kiểm tra sự trùng lặp của id, bị trùng thì hiện lỗi, không bị trùng thì tiếp tục
        -Kiểm tra xem ngày sinh nhập vào có đúng và hợp lệ không
        -Kiểm tra điểm số nhập vào có hợp lệ không
        -Xuất danh sách các thí sinh trên 15 điểm.

*/
#include "Candidate.h"

int main() {
    Candidate test;
    test.run();
    return 0;
}



