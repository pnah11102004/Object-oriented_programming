#pragma once
#ifndef _TamGiac
#include <iostream>
#include <math.h>
#define epsilon 0.0000000001
using namespace std;
class DIEM
{
private:
    double x, y;
public:
    ~DIEM(); //deconstructor
    DIEM(double = 0, double = 0);

    double GetX(); //constructor
    double GetY();
    void SetX(double);
    void SetY(double);
    void SetXY(double, double);

    void Nhap();
    void Xuat();

    bool KiemTraTrungNhau(const DIEM&);
    void DiChuyen(double, double);
    double Tinhkhoangcach(DIEM&);
    DIEM TimDiemDoiXung();
    bool KiemTraTamGiacHopLe(DIEM&, DIEM&);
    bool KiemTraTamGiacHopLe(double, double, double);
    double TinhChuViTamGiac(DIEM&, DIEM&);
    double TinhDienTichTamGiac(DIEM&, DIEM&);
    string PhanLoaiTamGiac(DIEM&, DIEM&);
};
#endif 