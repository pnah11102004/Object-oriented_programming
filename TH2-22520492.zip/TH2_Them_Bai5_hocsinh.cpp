#include "TH2_Them_Bai5_hocsinh.h"
#include <iostream>

HocSinh::HocSinh() {
    tenHS = "";
    diemVan = 0.0;
    diemToan = 0.0;
}

HocSinh::HocSinh(string ten, float van, float toan) {
    tenHS = ten;
    diemVan = van;
    diemToan = toan;
}

void HocSinh::nhap() {
    cout << "Nhap ten hoc sinh: ";
    getline(cin, tenHS);
    cout << "Nhap diem Van: ";
    cin >> diemVan;
    cout << "Nhap diem Toan: ";
    cin >> diemToan;
    if (diemVan<0||diemVan>10)
    {
    cout<<"Loi.Xin nhap lai diem Van: ";
    cin>>diemVan;
    }
    if (diemToan<0||diemToan>10)
    {
    cout<<"Loi.Xin nhap lai diem Toan: ";
    cin>>diemToan;
    }
}

void HocSinh::xuat() {
    cout << "Thong tin hoc sinh:" <<endl;
    cout << "Ten: " << tenHS << endl;
    cout << "Diem Van: " << diemVan << endl;
    cout << "Diem Toan: " << diemToan << endl;
    cout << "Diem trung binh: " << tinhDTB() << endl;
    cout << "Xep loai: " << xepLoai() << endl;
}

float HocSinh::tinhDTB() {
    return (diemVan + diemToan) / 2.0;
}

string HocSinh::xepLoai() {
    float dtb = tinhDTB();
    if (dtb >= 8.0) {
        return "Gioi";
    } else if (dtb >= 6.5) {
        return "Kha";
    } else if (dtb >= 5.0) {
        return "Trung binh";
    } else {
        return "Yeu";
    }
}
