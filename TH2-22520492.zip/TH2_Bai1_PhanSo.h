#ifndef TH2_Bai1_PHANSO_H_INCLUDED
#define TH2_Bai1_PHANSO_H_INCLUDED

class PhanSo {
    private:
        int tuSo;
        int mauSo;
    public:
        PhanSo();
        PhanSo(int tu, int mau);
        void nhap();
        void xuat();
        PhanSo cong(PhanSo b);
        PhanSo tru(PhanSo b);
        PhanSo nhan(PhanSo b);
        PhanSo chia(PhanSo b);
};

#endif // PHANSO_H_INCLUDED
