#include <iostream>
#include "TH2_Bai1_PhanSo.h"

using namespace std;

PhanSo::PhanSo() {
    tuSo = 0;
    mauSo = 1;
}

PhanSo::PhanSo(int tu, int mau) {
    tuSo = tu;
    mauSo = mau;
}

void PhanSo::nhap() {
    cout << "Nhap tu so: ";
    cin >> tuSo;
    cout << "Nhap mau so: ";
    cin >> mauSo;
}

void PhanSo::xuat() {
    cout << tuSo << "/" << mauSo;
}

PhanSo PhanSo::cong(PhanSo b) {
    PhanSo c;
    c.tuSo = tuSo*b.mauSo + mauSo*b.tuSo;
    c.mauSo = mauSo*b.mauSo;
    return c;
}

PhanSo PhanSo::tru(PhanSo b) {
    PhanSo c;
    c.tuSo = tuSo*b.mauSo - mauSo*b.tuSo;
    c.mauSo = mauSo*b.mauSo;
    return c;
}

PhanSo PhanSo::nhan(PhanSo b) {
    PhanSo c;
    c.tuSo = tuSo*b.tuSo;
    c.mauSo = mauSo*b.mauSo;
    return c;
}

PhanSo PhanSo::chia(PhanSo b) {
    PhanSo c;
    if (b.tuSo == 0) {
        cout << "Khong the chia cho 0";
        return c;
    }
    c.tuSo = tuSo*b.mauSo;
    c.mauSo = mauSo*b.tuSo;
    return c;
}
