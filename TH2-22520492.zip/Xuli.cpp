﻿#include "Candidate.h"

string Candidate:: getID() const {
    return ID;
}
string Candidate:: getTen() const {
    return Ten;
}
string Candidate:: getBD() const {
    return BD;
}
float Candidate:: getToan() const {
    return Toan;
}
float Candidate:: getVan() const {
    return Van;
}
float Candidate:: getAnh() const {
    return Anh;
}
void Candidate:: setID(const string& id) {
    this->ID = id;
}
void Candidate:: setTen(const string& ten) {
    this->Ten = ten;
}
void Candidate:: setBD(const string& bd) {
    this->BD = bd;
}
float Candidate:: tong() {
    return Toan + Van + Anh;
}
void Candidate:: setToan(const float& toan) {
    this->Toan = toan;
}
void Candidate:: setVan(const float& van) {
    this->Van = van;
}
void Candidate:: setAnh(const float& anh) {
    this->Anh = anh;
}
float Candidate:: getSum() const {
    return Toan + Anh + Van;
}
//Khai báo hàm điều kiện để ngày sinh hơp lệ
bool Candidate:: NgayHopLe() const {
    std::string BD = "12/04/2023";
    std::istringstream iss(BD);
    std::string d_str, m_str, y_str;
    std::getline(iss, d_str, '/');
    std::getline(iss, m_str, '/');
    std::getline(iss, y_str);

    int d = std::stoi(d_str);
    int m = std::stoi(m_str);
    int y = std::stoi(y_str);

    std::cout << "Day: " << d << "\n";
    std::cout << "Month: " << m << "\n";
    std::cout << "Year: " << y << "\n";
    if (y < 1900 || y>2023) { return false; }
    if (m < 1 || m > 12) {
        return false;
    }
    int daysInMonth = 31;
    if (m == 4 || m == 6 || m == 9 || m == 11) {
        daysInMonth = 30;
    }
    else if (m == 2) {
        if ((y % 4 == 0 && y % 100 != 0) || y % 400 == 0) {
            daysInMonth = 29;
        }
        else {
            daysInMonth = 28;
        }
    }
    if (d < 1 || d > daysInMonth) {
        return false;
    }
    return true;
}
bool Candidate:: HopLe() const {
    if (Ten.empty() || !NgayHopLe() || Toan < 0 || Toan > 10 || Van < 0 || Van > 10 || Anh < 0 || Anh > 10) {
        return false;
    }
    else {
        return true;
    }
}

void Candidate::run() {
    int n;
    cout << "Nhap so thi sinh: ";
    cin >> n;
    for (int i = 0; i < n; i++) {
        Candidate c;
        //Nhap Input
        cout << "\nCandidate " << i + 1 << ":\n";
        cout << "Nhap ID: ";
        string id;
        cin >> id;
        c.setID(id);
        //Kiem tra xem co trung ID khong
        while (find_if(candidates.begin(), candidates.end(), [&](const Candidate& x) {
            return x.getID() == c.getID();
            }) != candidates.end()) {
            cout << "ID da ton tai. Xin nhap lai: ";
            cin >> id;
            c.setID(id);
        }
        cout << "Nhap ten: ";
        string ten;
        cin >> ten;
        c.setTen(ten);
        cout << "Nhap ngay sinh (dd/mm/yyyy): ";
        string bd;
        cin >> bd;
        c.setBD(bd);
        // check xem ngay thang nam co hop le khong
        while (!c.NgayHopLe()) {
            cout << "Ngay sinh khong hop le. Xin nhap lai (dd/mm/yyyy): ";
            cin >> bd;
            c.setBD(bd);
        }
        //Nhap du lieu diem
        cout << "Nhap diem Toan: ";
        float toan;
        cin >> toan;
        c.setToan(toan);
        cout << "Nhap diem Van: ";
        float van;
        cin >> van;
        c.setVan(van);
        cout << "Nhap diem Anh: ";
        float anh;
        cin >> anh;
        c.setAnh(anh);
        //Kiểm tra điều kiện của điểm
        if (toan < 0 || toan>10)
        {
            cout << "Du lieu sai.Xin nhap lai diem toan (0-10): ";
            cin >> toan;
            c.setToan(toan);
        }
        if (van < 0 || van>10)
        {
            cout << "Du lieu sai.Xin nhap lai diem van (0-10): ";
            cin >> van;
            c.setVan(van);
        }
        if (anh < 0 || anh>10)
        {
            cout << "Du lieu sai.Xin nhap lai diem anh (0-10): ";
            cin >> anh;
            c.setAnh(anh);
        }
        candidates.push_back(c);
    }
    //In danh sach thi sinh có điểm trên 15

    for (int i = 0; i < candidates.size(); i++) {
        if (candidates[i].getSum() > 15) {
            cout << "Thi sinh co diem lon hon 15 :\n";
            cout << "\nCandidate " << i + 1 << ":\n";
            cout << "ID: " << candidates[i].getID() << endl;
            cout << "Ten: " << candidates[i].getTen() << endl;
            cout << "Ngay sinh: " << candidates[i].getBD() << endl;
            cout << "Diem Toan: " << candidates[i].getToan() << endl;
            cout << "Diem Van: " << candidates[i].getVan() << endl;
            cout << "Diem Anh: " << candidates[i].getAnh() << endl;
            cout << "Tong diem: " << candidates[i].getSum() << endl;
        }
    }
}   
