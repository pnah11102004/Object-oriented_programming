#include "TH2_Them_Bai5_hocsinh.h"
#include "TH2_Them_Bai5_hocsinh.cpp"
#include <iostream>
int main() {
HocSinh t2;

    t2.nhap();


    // Xuất thông tin học sinh t2
    cout << "Thong tin hoc sinh t2:" << endl;
    t2.xuat();

    // Tính điểm trung bình và xếp loại học sinh t2
    float dtb = t2.tinhDTB();
    string xepLoai = t2.xepLoai();



return 0;
}
