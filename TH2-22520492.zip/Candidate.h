﻿#pragma once
#ifndef _Candidate
#include <iostream>
#include<string>
#include<vector>
#include<algorithm>
#include<ctime>
#include<sstream>
using namespace std;
//Khai báo biến
class Candidate {
private:
    string ID;
    string Ten;
    string BD;
    float Toan;
    float Van;
    float Anh;
    vector<Candidate> candidates;
public:
    //Khai báo các phương thức để cấp quyền ghi/đọc (set/get) giá trị cho các  thuộc tính
    Candidate() {}
    string getID() const;
    string getTen() const;
    string getBD() const;
    float getToan() const;
    float getVan() const;
    float getAnh() const;
    void setID(const string& id);
    void setTen(const string& ten);
    void setBD(const string& bd);
    float tong();
    void setToan(const float& toan);
    void setVan(const float& van);
    void setAnh(const float& anh);
    float getSum() const;
    //Khai báo hàm điều kiện để ngày sinh hơp lệ
    bool NgayHopLe() const;
    bool HopLe() const;
    void run();
};

#endif // !
