#include<iostream>
#include "TH2_Them_Bai1_TAMGIAC.h"
#include "TH2_Them_Bai1.cpp"
using namespace std;
int main()
{
    DIEM d1, d2, d3;
    cout << "Nhap diem d1 \n";
    d1.Nhap();
    cout << "Nhap diem d2 \n";
    d2.Nhap();
    cout << "d1("; d1.Xuat(); cout << ")\n";
    cout << "d2("; d2.Xuat(); cout << ")\n";
    cout << "--------------------------------------------------------------\n";
    d1.DiChuyen(0, 3);
    cout << "Di chuyen d1 (dx=0, dy = 3) =>";
    cout << "d1("; d1.Xuat(); cout << ")\n";
    cout << "--------------------------------------------------------------\n";
    if (d1.KiemTraTrungNhau(d2))
    {
        cout << "d1 trung d2 \n";
    }
    else
    {
        cout << "d1 khong trung d2\n";
    }
    cout << "--------------------------------------------------------------\n";
    cout << "Khoang cach tu d1 den d2 la: " << d1.Tinhkhoangcach(d2) << endl;
    cout << "--------------------------------------------------------------\n";
    DIEM ddx = d1.TimDiemDoiXung();
    cout << "Toa do diem doi xung cua d1 la: ddx("; ddx.Xuat(); cout << ")\n";
    cout << "--------------------------------------------------------------\n";
    d3.Nhap();
    cout << "Chu vi cua tam giac tao boi 3 diem d1, d2, d3 la: " << d1.TinhChuViTamGiac(d2, d3) << endl;
    cout << "--------------------------------------------------------------\n";
    cout << "Dien tich cua tam giac tao boi 3 diem d1, d2, d3 la: " << d1.TinhDienTichTamGiac(d2, d3) << endl;
    cout << "--------------------------------------------------------------\n";

    if (d1.KiemTraTamGiacHopLe(d2, d3))
    {
        cout << "Phan loai: " << d1.PhanLoaiTamGiac(d2, d3) << endl;
    }
    cout << "--------------------------------------------------------------\n";
    return 0;
}
