#include "TH2_Bai2_SOPHUC.h"
#include <iostream>

using namespace std;

SOPHUC::SOPHUC(double thuc, double ao)
{
    this -> thuc = thuc;
    this -> ao = ao;
}

 double SOPHUC :: Getthuc()
{
    return thuc;
}

double SOPHUC :: Getao()
{
    return ao;
}

 void SOPHUC ::Setthuc(double thuc)
{
    this -> thuc = thuc;
}
 void SOPHUC ::Setao(double ao)
{
    this -> ao = ao;
}
 void SOPHUC ::Setsophuc(double thuc, double ao)
{
    this -> thuc= thuc;
    this -> ao = ao;

}

 void SOPHUC::Nhap()
{
    cout << "Nhap phan thuc: ";
    cin >> thuc;
    cout << "Nhap phan ao: ";
    cin >> ao;
}

 void SOPHUC::Xuat()
{
    if (thuc == 0 && ao != 0)
    {
        cout << ao << "i" << endl;
    }
    else if (ao == 1)
        cout << thuc <<"+ i"<< endl;
    else if (ao > 0)
    cout << thuc << " + " << ao << "i" << endl;
    else if (ao == 0) cout << thuc << endl;
    else if (ao == -1)
        cout << thuc << " - i" << endl;
    else cout << thuc << " - " << -ao << "i " << endl;
}

 SOPHUC SOPHUC ::Cong(const SOPHUC& sp)
{
    return SOPHUC (thuc+ sp.thuc, ao+ sp.ao);
}

 SOPHUC SOPHUC ::Tru(const SOPHUC& sp)
{
    return SOPHUC (thuc - sp.thuc, ao - sp.ao);
}

 SOPHUC SOPHUC ::Nhan(const SOPHUC& sp)
{
    return SOPHUC (thuc*sp.thuc - ao*sp.ao , thuc*sp.ao + ao*sp.thuc);
}

 SOPHUC SOPHUC ::Chia(const SOPHUC& sp)
{
    if (sp.thuc*sp.thuc + sp.ao*sp.ao==0)
        cout << "So phuc khong hop le";

    else
    return SOPHUC (1.0*(thuc*sp.thuc + ao * sp.ao)/(sp.thuc*sp.thuc + sp.ao*sp.ao), 1.0*(sp.thuc* ao - thuc*sp.ao)/(sp.thuc*sp.thuc + sp.ao*sp.ao));
}
