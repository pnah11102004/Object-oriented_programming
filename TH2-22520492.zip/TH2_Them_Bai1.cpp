﻿#include "TH2_Them_Bai1_TAMGIAC.h"

DIEM::~DIEM()
{
    cout << "Da huy 1 DIEM\n";
}

DIEM::DIEM(double x, double y)
{
    this->x = x;
    this->y = y;
}

double DIEM::GetX()
{
    return x;
}

double DIEM::GetY()
{
    return y;
}

void DIEM::SetX(double x)
{
    this->x = x;
}

void DIEM::SetY(double y)
{
    this->y = y;

}

void DIEM::SetXY(double x, double y)
{
    this->x = x;
    this->y = y;
}

void DIEM::Nhap()
{
    cout << "Nhap hoanh do: ";
    cin >> x;
    cout << "Nhap tung do: ";
    cin >> y;
}

void DIEM::Xuat()
{
    cout << x << "," << y;
}

void DIEM::DiChuyen(double dx, double dy)
{
    x += dx;
    y += dy;
}

bool DIEM::KiemTraTrungNhau(const DIEM& d)
{
    return this->x == d.x && this->y == d.y;
}

double DIEM::Tinhkhoangcach(DIEM& d)
{
    return sqrt(pow(x - d.x, 2) + pow(y - d.y, 2));
}

DIEM DIEM::TimDiemDoiXung()
{
    return DIEM(-x == 0 ? 0 : -x, -y == 0 ? 0 : -y);
}

bool DIEM::KiemTraTamGiacHopLe(DIEM& d1, DIEM& d2)
{
    double a = this->Tinhkhoangcach(d1);
    double b = d1.Tinhkhoangcach(d2);
    double c = d2.Tinhkhoangcach(*this);
    return a > 0 && b > 0 && c > 0 && a + b > c && b + c > a && c + a > b;
}

bool DIEM::KiemTraTamGiacHopLe(double a, double b, double c)
{
    return a > 0 && b > 0 && c > 0 && a + b > c && b + c > a && c + a > b;
}

double DIEM::TinhChuViTamGiac(DIEM& d1, DIEM& d2)
{
    double a = Tinhkhoangcach(d1);
    double b = d1.Tinhkhoangcach(d2);
    double c = d2.Tinhkhoangcach(*this);
    return KiemTraTamGiacHopLe(a, b, c) ? a + b + c : 0;
}


double DIEM::TinhDienTichTamGiac(DIEM& d1, DIEM& d2)
{
    double a = Tinhkhoangcach(d1);
    double b = d1.Tinhkhoangcach(d2);
    double c = d2.Tinhkhoangcach(*this);
    double p = (a + b + c) / 2;
    return KiemTraTamGiacHopLe(a, b, c) ? sqrt(p * (p - a) * (p - b) * (p - c)) : 0;
}

string DIEM::PhanLoaiTamGiac(DIEM& d1, DIEM& d2)
{
    double a = Tinhkhoangcach(d1);
    double b = d1.Tinhkhoangcach(d2);
    double c = d2.Tinhkhoangcach(*this);
    string chuoikq = "";
    if (KiemTraTamGiacHopLe(d1, d2))
    {
        if (a == b && b == c)
            chuoikq = "TG deu";
        else if (a == b || b == c || c == a)
        {
            if (a * a + b * b - c * c <= epsilon || b * b + c * c - a * a <= epsilon || a * a + c * c - b * b <= epsilon)
                chuoikq = "TG vuong can";
            else chuoikq = "TG can";
        }
        else if (a * a + b * b == c * c || b * b + c * c == a * a || a * a + c * c == b * b)
            chuoikq = "TG vuong";
        else chuoikq = "TG thuong";
    }
    else chuoikq = "TG khong hop le";
    return chuoikq;
}
