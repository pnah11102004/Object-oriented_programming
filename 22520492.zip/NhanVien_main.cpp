#include <iostream>
#include <vector>
#include "NhanVien.h"
#include<iomanip>
using namespace std;

int main() {
    vector<Employee*> employees;

    // Nhập thông tin nhân viên
    int choice;
    do {
        cout << "1. Nhan vien van phong\n";
        cout << "2. Nhan vien san xuat\n";
        cout << "0. Ket thuc\n";
        cout << "Chon loai nhan vien: ";
        cin >> choice;

        if (choice == 1) {
            OfficeEmployee* employee = new OfficeEmployee();
            employee->input();
            employees.push_back(employee);
        } else if (choice == 2) {
            ProductionEmployee* employee = new ProductionEmployee();
            employee->input();
            employees.push_back(employee);
        }
    } while (choice != 0);

    // Tính lương và in thông tin nhân viên
    cout << "=========================\n";
    for (Employee* employee : employees) {
        employee->calculateSalary();
        employee->display();
        cout << "=========================\n";
    }

    // Giải phóng bộ nhớ
    for (Employee* employee : employees) {
        delete employee;
    }
    employees.clear();

    return 0;
}
