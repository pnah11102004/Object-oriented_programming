#include <iostream>
#include <string>
#include <vector>

using namespace std;

class NhanVien {
protected:
    string maso, hoten, pban;
public:
    NhanVien(string = "", string = "", string = "");
    string GetMaSo();
    string GetHoTen();
    string GetPhongBan();
    void SetMaSo(string);
    void SetHoTen(string);
    void SetPhongBan(string);
    virtual double GetHSLuong();
    virtual double GetHSPhuCap();
    virtual double GetTCong();
    virtual double GetSoNgay();
    virtual double GetHSVGio();
    virtual void SetHSLuong(double);
    virtual void SetHSPhuCap(double);
    virtual void SetTCong(double);
    virtual void SetSoNgay(double);
    virtual void SetHSVGio(double);
    virtual void Nhap()
    {
    cin.ignore();
    cout << "Ma so: "; getline(cin, maso);
    cout << "Ho ten: "; getline(cin, hoten);
    cout << "Phong ban: "; getline(cin, pban);
    }
    virtual void Xuat()
    {
    cout << "Ma so: " << maso << endl;
    cout << "Ho ten: " << hoten << endl;
    cout << "Phong ban: " << pban << endl;
    }
    virtual string GetLoai() = 0;
    virtual double Tinhtienluong() = 0;
};
class NVBienChe :public NhanVien {
private:
    double hsluong, hsphucap;
public:
    NVBienChe(string = "", string = "", string = "", double = 0, double = 0);
    double GetHSLuong();
    double GetHSPhuCap();
    void SetHSLuong(double);
    void SetHSPhuCap(double);
    void Nhap();
    void Xuat();
    double Tinhtienluong();
    string GetLoai();
};
class NVHopDong :public NhanVien {
private:
    double tcong, songay, hsvgio;
public:
    NVHopDong(string = "", string = "", string = "", double = 0, double = 0, double = 0);
    double GetTCong();
    double GetSoNgay();
    double GetHSVGio();
    void SetTCong(double);
    void SetSoNgay(double);
    void SetHSVGio(double);
    void Nhap();
    void Xuat();
    double Tinhtienluong();
    string GetLoai();
};
class QLy {
private:
    NhanVien** pnv;
    int sl;
public:
    QLy();
    ~QLy();
    int GetSL();
    void Nhap();
    void Xuat();
    NhanVien* Nhap1();
    void LietkeNVBC();
    void DemNC26();
    void LTBNVBC();
    void TLPKeToan();
    void KiemTraNVHD();
    void TimNVBC();
    void SapXep();
    void ThemNV();
    void XoaNV();
    void TimKiemNV();
};
NhanVien::NhanVien(string ms, string ht, string pban) : maso(ms), hoten(ht), pban(pban) {}
string NhanVien::GetMaSo() { return maso; }
string NhanVien::GetHoTen() { return hoten; }
string NhanVien::GetPhongBan() { return pban; }
void NhanVien::SetMaSo(string ms) { maso = ms; }
void NhanVien::SetHoTen(string ht) { hoten = ht; }
void NhanVien::SetPhongBan(string pban) { pban = pban; }
double NhanVien::GetHSLuong() { return -1; }
double NhanVien::GetHSPhuCap() { return -1; }
double NhanVien::GetTCong() { return -1; }
double NhanVien::GetSoNgay() { return -1; }
double NhanVien::GetHSVGio() { return -1; }
void NhanVien::SetHSLuong(double hsl) { return; }
void NhanVien::SetHSPhuCap(double hspc) { return; }
void NhanVien::SetTCong(double tc) { return; }
void NhanVien::SetSoNgay(double sn) { return; }
void NhanVien::SetHSVGio(double hsvg) { return; }
NVBienChe::NVBienChe(string ms, string ht, string pban, double hsluong, double hsphucap) : NhanVien(ms, ht, pban), hsluong(hsluong), hsphucap(hsphucap) {}
double NVBienChe::GetHSLuong() { return hsluong; }
double NVBienChe::GetHSPhuCap() { return hsphucap; }
void NVBienChe::SetHSLuong(double hsl)
{
    cout << "He so luong: "; cin >> hsl;
    hsluong = hsl;
}
void NVBienChe::SetHSPhuCap(double hspc)
{
    cout << "He so phu cap: "; cin >> hspc;
    hsphucap = hspc;
}
void NVBienChe::Nhap()
{
    NhanVien::Nhap();
    cout << "He so luong: "; cin >> this->hsluong;
    cout << "He so phu cap chuc vu: "; cin >> this->hsphucap;
}
void NVBienChe::Xuat()
{
    NhanVien::Xuat();
    cout << "He so luong la: " << hsluong << endl << "He so phu cap chuc vu: " << hsphucap << endl;
}
double NVBienChe::Tinhtienluong()
{
    double luong;
    luong = (1 + hsluong + hsphucap) * 1000;
    return luong;
}
string NVBienChe::GetLoai()
{
    return "NVBienChe";
}
NVHopDong::NVHopDong(string ms, string ht, string pban, double tcong, double songay, double hsvgio) : NhanVien(ms, ht, pban), tcong(tcong), songay(songay), hsvgio(hsvgio) {}
double NVHopDong::GetTCong()
{
    return tcong;
}
double NVHopDong::GetSoNgay()
{
    return songay;
}
double NVHopDong::GetHSVGio()
{
    return hsvgio;
}
void NVHopDong::SetTCong(double tc)
{
    cout << "Tien cong: "; cin >> tc;
    tcong = tc;
}
void NVHopDong::SetSoNgay(double sn)
{
    cout << "So ngay lam viec: "; cin >> sn;
    songay = sn;
}
void NVHopDong::SetHSVGio(double hsvg)
{
    cout << "He so vuot gio: "; cin >> hsvg;
    hsvgio = hsvg;
}
void NVHopDong::Nhap()
{
    NhanVien::Nhap();
    cout << "Tien cong: "; cin >> this->tcong;
    cout << "So ngay cong: "; cin >> this->songay;
    cout << "He so vuot gio: "; cin >> this->hsvgio;
}
void NVHopDong::Xuat()
{
    NhanVien::Xuat();
    cout << "Tien cong: " << tcong << endl << "So ngay cong: " << songay <<endl<< "He so vuot gio: " << hsvgio<<endl;
}
double NVHopDong::Tinhtienluong()
{
    double luong;
    luong = tcong * songay * (1 + hsvgio);
    return luong;
}
string NVHopDong::GetLoai()
{
    return "NVHopDong";
}
QLy::QLy()
{
    pnv = NULL;
    sl = 0;
}
QLy::~QLy()
{
    for (int i = 0; i < sl; i++)
        delete pnv[i];
    delete[]pnv;
    pnv = NULL;
    sl = 0;
}
int QLy::GetSL() { return sl; }
void QLy::Nhap()
{
    int loai;
    do {
        cout << "Nhap so luong nhan vien: ";
        cin >> sl;
    } while (sl < 1);
    pnv = new NhanVien * [sl];
    for (int i = 0; i < sl; i++)
    {
        cout << "Nhap thong tin nhan vien thu " << i + 1;
        do {
            cout << ": Nhap loai nhan vien:" << "\n1_Nhan vien Bien Che" << "; 2_Nhan vien Hop Dong"<< endl;
            cin >> loai;
        } while (loai < 1 || loai > 2);
        if (loai == 1) {
            pnv[i] = new NVBienChe;
        }
        else {
            pnv[i] = new NVHopDong;
        }
        pnv[i]->Nhap();
    }
}
NhanVien* QLy::Nhap1()
{
    int loai;
    NhanVien* nv;
    do {
        cout << "Nhap loai nhan vien:" << "\n1_Nhan vien Bien Che" << "\n2_Nhan vien Hop Dong" << endl;
        cin >> loai;
    } while (loai < 1 || loai > 2);
    if (loai == 1)
        nv = new NVBienChe;
    else
        nv = new NVHopDong;
    nv->Nhap();
    return nv;
}
void QLy::Xuat()
{
    for (int i = 0; i < sl; i++)
        pnv[i]->Xuat();
}
void QLy::LietkeNVBC()
{
    int dem = 0;
    for (int i = 0; i < sl; i++)
        if (pnv[i]->GetLoai() == "NVBienChe" && pnv[i]->GetHSLuong() >= 3.5)
        {
            pnv[i]->Xuat();
            dem++;
        }
    if (dem == 0)
        cout << "Ko co nhan vien bien che co he so luong tren 3.5\n";
    else
        cout << "So luong: " << dem << endl;
}
void QLy::DemNC26()
{
    int dem = 0;
    for (int i = 0; i < sl; i++)
        if (pnv[i]->GetLoai() == "NVHopDong" && pnv[i]->GetSoNgay() == 26)
        {
            pnv[i]->Xuat();
            dem++;
        }
    if (dem == 0)
        cout << "Ko co nhan vien hop dong co so ngay cong la 26\n";
    else
        cout << "So NVHD co 26 ngay cong la: " << dem << endl;
}
void QLy::LTBNVBC()
{
    int s = 0, dem = 0;
    for (int i = 0; i < sl; i++)
        if (pnv[i]->GetLoai() == "NVBienChe")
        {
            s += pnv[i]->Tinhtienluong();
            dem++;
        }
    if (dem == 0)
        cout << "Ko co nhan vien Bien Che\n";
    else
        cout << "Luong TB tra cho NVBC la: " << s / dem << endl;
}
void QLy::TLPKeToan()
{
    int s = 0, dem = 0;
    for (int i = 0; i < sl; i++)
        if (pnv[i]->GetPhongBan() == "Ke Toan")
        {
            s += pnv[i]->Tinhtienluong();
            dem++;
        }
    if (dem == 0)
        cout << "Ko co nhan vien phong ke toan";
    else
        cout << "Tong luong tra cho phong ke toan la: " << s << endl;
}
void QLy::KiemTraNVHD()
{
    for (int i = 0; i < sl; i++) {
        if (pnv[i]->GetLoai() == "NVHopDong" && pnv[i]->GetSoNgay() == 30)
            cout << "Ko co NVHD nao nghi";
        else if (pnv[i]->GetLoai() == "NVHopDong" && pnv[i]->GetSoNgay() < 30)
        {
            pnv[i]->Xuat();
            cout << "Nghi " << 30 - pnv[i]->GetSoNgay() << " ngay";
        }
    }
}
void QLy::ThemNV()
{
    sl++;
    int loai;
        do {
            cout << ": Nhap loai nhan vien:" << "\n1_Nhan vien Bien Che" << "; 2_Nhan vien Hop Dong"<< endl;
            cin >> loai;
        } while (loai < 1 || loai > 2);
        if (loai == 1) {
            pnv[sl-1] = new NVBienChe;
        }
        else {
            pnv[sl-1] = new NVHopDong;
        }
        pnv[sl-1]->Nhap();
}
void QLy::XoaNV()
{
    string maxoa;
    cout << "Nhap ma so nv can xoa: ";
    cin >> maxoa;
    bool daxoa = false;
    for(int i = 0; i < sl; i ++)
    if(pnv[i]->GetMaSo() == maxoa)
    {
        delete pnv[i];
        daxoa = true;
    }
    if(daxoa)
        cout << "Da xoa "<< maxoa << endl;
    else
        cout << "Ko tim thay" << endl;
}
int main()
{
    QLy ql;
    int chon;
    do {
        cout << "===================QUAN LY NHAN VIEN=====================\n";
        cout << "1-Nhap\n";
        cout << "2-Xuat\n";
        cout << "3-Liet ke NVBC co he so luong 3.5 tro len\n";
        cout << "4-Dem so luong NVHD co so ngay cong la 26\n";
        cout << "5-Tinh tong tien luong tra cho phong ke toan\n";
        cout << "6-Tinh luong TB NVBC\n";
        cout << "7-Kiem tra NVHD ko di lam ngay nao ko\n";
        cout << "8-Them 1 NV moi\n";
        cout << "9-Xoa NV\n";
        cout << "0-Thoat chuong trinh\n";
        cout << "=========================================================\n";
        cout << "Ban chon: ";
        cin >> chon;
        switch (chon) {
        case 0:
            if (ql.GetSL() > 0)
                ql.~QLy();
            cout << "Thoat chuong trinh";
            break;
        case 1:
            if (ql.GetSL() > 0)
                ql.~QLy();
            ql.Nhap();
            break;
        case 2:
            if (ql.GetSL() > 0)
                ql.Xuat();
            else
                cout << "chua nhap thong tin";
            break;
        case 3:
            if (ql.GetSL() > 0)
                ql.LietkeNVBC();
            else
                cout << "Chua nhap thong tin";
            break;
        case 4:
            if (ql.GetSL() > 0)
                ql.DemNC26();
            else
                cout << "chua nhap thong tin";
            break;
        case 5:
            if (ql.GetSL() > 0)
                ql.TLPKeToan();
            else
                cout << "chua nhap thong tin";
            break;
        case 6:
            if (ql.GetSL() > 0)
                ql.LTBNVBC();
            else
                cout << "chua nhap thong tin";
            break;
        case 7:
            if (ql.GetSL() > 0)
                ql.KiemTraNVHD();
        else
                cout << "chua nhap thong tin";
            break;
        case 8:
            if (ql.GetSL() > 0)
                ql.ThemNV();
            else
                cout << "chua nhap thong tin";
            break;
        case 9:
            if (ql.GetSL() > 0)
                ql.XoaNV();
            else
                cout << "chua nhap thong tin";
            break;
        }
    } while (chon != 0);
    return 0;
}

