/*#include "NhanVien.h"
#include <iostream>

using namespace std;

Employee::Employee(const string& name, const string& birthDate)
    : name(name), birthDate(birthDate) {}

Employee::~Employee() {}

void Employee::displayInformation() const {
    cout << "Name: " << name << endl;
    cout << "Birth Date: " << birthDate << endl;
}

void Employee::input() {
    cout << "Enter name: ";
    getline(cin, name);
    cout << "Enter birth date: ";
    getline(cin, birthDate);
}

OfficeEmployee::OfficeEmployee(const string& name, const string& birthDate, int workingDays)
    : Employee(name, birthDate), workingDays(workingDays) {}

OfficeEmployee::~OfficeEmployee() {}

double OfficeEmployee::calculateSalary() const {
    return workingDays * 100000;
}

void OfficeEmployee::displayInformation() const {
    Employee::displayInformation();
    cout << "Employee Type: Office Employee" << endl;
    cout << "Working Days: " << workingDays << endl;
}

void OfficeEmployee::input() {
    Employee::input();
    cout << "Enter working days: ";
    cin >> workingDays;
    cin.ignore();  // Xóa bộ nhớ đệm để nhận các dữ liệu nhập tiếp theo
}

ProductionEmployee::ProductionEmployee(const string& name, const string& birthDate, int numOfProducts)
    : Employee(name, birthDate), numOfProducts(numOfProducts) {}

ProductionEmployee::~ProductionEmployee() {}

double ProductionEmployee::calculateSalary() const {
    return numOfProducts * 5000;
}

void ProductionEmployee::displayInformation() const {
    Employee::displayInformation();
    cout << "Employee Type: Production Employee" << endl;
    cout << "Number of Products: " << numOfProducts << endl;
}

void ProductionEmployee::input() {
    Employee::input();
    cout << "Enter number of products: ";
    cin >> numOfProducts;
    cin.ignore();  // Xóa bộ nhớ đệm để nhận các dữ liệu nhập tiếp theo
}
*/
