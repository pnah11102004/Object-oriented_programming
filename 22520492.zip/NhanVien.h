#ifndef NHANVIEN_H_INCLUDED
#define NHANVIEN_H_INCLUDED


#include<iomanip>
#include <string>

using namespace std;

class Employee {
protected:
    string name;
    string birthDate;
    double salary;

public:
    Employee() {
        name = "";
        birthDate = "";
        salary = 0.0;
    }

    void input() {
        cout << "Ho ten: ";
        cin.ignore();
        getline(cin, name);
        cout << "Ngay sinh: ";
        getline(cin, birthDate);
    }

    virtual void calculateSalary() = 0;

    void display() {
        cout << fixed << setprecision(2);
        cout << "Ho ten: " << name << endl;
        cout << "Ngay sinh: " << birthDate << endl;
        cout << "Luong: " << salary << endl;
    }
};

class OfficeEmployee : public Employee {
private:
    int workDays;

public:
    OfficeEmployee() : Employee() {
        workDays = 0;
    }

    void input() {
        Employee::input();
        cout << "So ngay lam viec: ";
        cin >> workDays;
    }

    void calculateSalary() {
        salary = workDays * 100000;
    }
};

class ProductionEmployee : public Employee {
private:
    int products;

public:
    ProductionEmployee() : Employee() {
        products = 0;
    }

    void input() {
        Employee::input();
        cout << "So san pham: ";
        cin >> products;
    }

    void calculateSalary() {
        salary = 5000 * (float)products;
    }
};

#endif // EMPLOYEE_H
