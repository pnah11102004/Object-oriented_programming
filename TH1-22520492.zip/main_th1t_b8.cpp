/*8. Đổi ra số nhị phân tương ứng với số thập phân được nhập vào.
-Input: 1 số thập phân
-Output: số nhị phân tương ứng
-GT: Sử dụng phéo toán bit và vòng lặp
*/
#include <iostream>
using namespace std;
struct chuyendoi{
    int sothapphan;
    string sonhiphan;
    };
void chuyen(chuyendoi &cd) {
int n=cd.sothapphan;
string sonhiphan="";
while (n>0) {
    sonhiphan=(n%2==0?"0":"1")+sonhiphan;
    n/=2;
}
cd.sonhiphan=sonhiphan;


}
int main() {
chuyendoi cd;
cout<< "Nhap so thap phan: ";
cin >> cd.sothapphan;
chuyen(cd);
cout<<"So thap phan la: "<<cd.sothapphan<<endl;
cout<<"So nhi phan la: "<<cd.sonhiphan<<endl;
return 0;
}
