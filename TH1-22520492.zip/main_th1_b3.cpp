/* 3. Viết chương trình nhập vào hai phân số. Tính tổng, hiệu, tích, thương giữa chúng
và xuất kết quả.
- Input: 2 phân số
- Output: Tổng, hiệu, tích, thương 2 phân số và xuất kết quả
- GT:  -Nhập 2 phân số A, B
        - Tính A+B,A-B,A*B,A/B
        - Xuất kết quả
*/
 #include <iostream>
 using namespace std;
 typedef struct PHANSO
 {
     int Ts;
     int Ms;
 } PS;
//1. Nhap phan so
 void Nhap(PS& p)
 {
     cout<<"Nhap tu so: ";
     cin >> p.Ts;
     do
     {
         cout<<"Nhap mau so: ";
         cin >> p.Ms;
     } while (p.Ms==0);
 }
 //2.Quy dong 2 phan so
 void Quydong(PS x, PS y, int& a, int& b, int& Msc)
 {
     a=x.Ts*y.Ms;
     b=y.Ts*x.Ms;
     Msc=x.Ms*y.Ms;
 }
 //3.Tim uoc so chung lon nhat
 int uscln(int m, int n)
 {
     if(m%n==0)
        return n;
     return uscln(n,m%n);
 }
 //4.Rut gon 2 phan so
 void Rutgon(int a, int b)
 {
     int i=uscln(a,b);
     a=a/i;
     b=b/i;
     if((a<0&&b<0)||(a>0&&b<0))
     {
         a=-a;
         b=-b;
     }
     if(a%b==0) cout << a/b << endl;
     else cout << a << "/" << b << endl;
 }
 //5. Xuat ket qua
 void Xuat(PS x, PS y, int &a, int &b, int &Msc)
 {
     Quydong(x,y,a,b,Msc);
     cout << "Tong 2 phan so: ";
     Rutgon(a+b,Msc);
     cout<< "Hieu 2 phan so: ";
     Rutgon(a-b,Msc);
     cout << "Tich 2 phan so: ";
     Rutgon(x.Ts*y.Ts,x.Ms*y.Ms);
     cout<< "Thuong 2 phan so: ";
     Rutgon(x.Ts*y.Ms,y.Ts*x.Ms);

 }
 int main()
 {
     PS PS1,PS2;
     int a,b,Msc;
     cout<<"Nhap phan so thu nhat: "<<endl;
     Nhap(PS1);
     cout<<"Nhap phan so thu hai: "<<endl;
     Nhap(PS2);
     Xuat(PS1,PS2,a,b,Msc);
     return 0;
 }

