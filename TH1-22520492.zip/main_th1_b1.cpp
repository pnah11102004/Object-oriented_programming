/*1. Viết chương trình nhập vào một phân số, rút gọn phân số và xuất kết quả.
- Input: Phân số(ts,ms)
- Output: Phân số tối giản
- GT:
    * Tìm USCLN(ts,ms)
    * Rút gọn phân số: ts = ts/USCLN, ms = sm/USCLN
    * Xuất phân số tối giản
*/
#include <iostream>

using namespace std;
struct PHANSO
{
	int ts, ms;
};
void Nhap(PHANSO &ps)
{
	cout << "nhap tu so: ";
	cin >> ps.ts;
	do
	{
		cout << "nhap mau so ( khac 0 ): ";
		cin >> ps.ms;
	} while (ps.ms == 0);
}
void nhap(PHANSO* ps)
{
	cout << "nhap tu so: ";
	cin >> ps->ts;
	do
	{
		cout << "nhap mau so ( khac 0 ): ";
		cin >> ps->ms;
	} while (ps->ms == 0);
}
int TimUSCLN(int& a, int& b)
{
	int uscln;
	a = abs(a);// |a|: absolute
	b = abs(b); // |b|
	if (a == 0 && b == 0)
		uscln = 1;
	else if (a == 0 || b == 0)
		uscln = a + b;
	else
	{
		//- khong dung giai thuat
		int min = a < b ? a : b;
		for (int i = min; i >= 1; i--)
		{
			if (a % i == 0 && b % i == 0)
			{
				uscln = i;
				break;
			}
		}

		//- dung giai thuat euclide
		/*while (a != b)
		{
			if (a > b) a -= b;
			else b -= a;
		}
		uscln = a;*/
	}
	return uscln;
}
void RutGon(PHANSO &ps)
{
	int uscln = TimUSCLN(ps.ts, ps.ms);
	ps.ts /= uscln;
	ps.ms /= uscln;
}

void Xuat(PHANSO ps)
{
	if (ps.ms < -1)
		cout << -ps.ts << "/" << -ps.ms;
	else if (ps.ms == -1)
		cout << -ps.ts;
	else if (ps.ms == 0)
		cout << "khong chia cho so 0";
	else if (ps.ms == 1)
		cout << ps.ts;
	else
		cout << ps.ts << "/" << ps.ms;
}
int main()
{
	//1.khai bao bien
	PHANSO ps1;

	//2.nhap lieu bien
	Nhap(ps1);

	//3.xu li tinh toan
	RutGon(ps1);

	//4. ket xuat ket qua
	Xuat(ps1);
}
