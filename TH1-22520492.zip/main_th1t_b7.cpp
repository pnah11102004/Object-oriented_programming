/*7.Nhập vào số tiền. Hãy tính và in ra số tờ tiền tương ứng của các mệnh giá giảm dần: 500k,
200k, 100k, 50k. (giả sử đổi hết mệnh giá lớn, phần dư mới đổi sang mệnh giá nhỏ hơn)
- Input: Số tiền
- Output: Số tiền tương ứng với các mệnh giá giảm dần
- GT: - Nhap tien
        - Tinh so tien cua tung menh gia
        - In ket qua
        */
#include <iostream>
using namespace std;

int main() {
    int a, to500k,to200k,to100k, to50k;
    cout << "Nhap so tien can doi: ";
    cin >> a;

    // Tính số tờ tiền của từng mệnh giá
    to500k = a / 500000;
    a %= 500000;
    to200k = a / 200000;
    a %= 200000;
    to100k = a / 100000;
    a %= 100000;
    to50k = a / 50000;

    // In ra số tờ tiền của từng mệnh giá
    cout << "So to tien 500k: " << to500k << endl;
    cout << "So to tien 200k: " << to200k << endl;
    cout << "So to tien 100k: " << to100k << endl;
    cout << "So to tien 50k: " << to50k << endl;
    return 0;
}
