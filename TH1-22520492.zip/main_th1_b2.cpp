/* 2. Viết chương trình nhập vào hai phân số, tìm phân số lớn nhất và xuất kết quả.
- Input: 2 Phân số(ts,ms)
- Output: Phân số lớn nhất
- GT:
    * So sánh 2 phân số
    * Xuất kết quả là phân số lớn hơn
*/

#include<iostream>
using namespace std;
//1.khai bao bien
struct PhanSo {
int ts,ms;
};
//2. Nhap bien
void NhapPhanSo(PhanSo &ps)
{
cout<<"Nhap tu so: ";
cin>>ps.ts;
cout<<"Nhap mau so(khac 0): ";
cin>>ps.ms;
}
//3.Sosanh va xuat ketqua
void Sosanh(PhanSo ps1, PhanSo ps2) {
	double val1 = (double)ps1.ts / ps1.ms;
	double val2 = (double)ps2.ts / ps2.ms;
	if (val1 < val2) {
		cout << "Phan so lon nhat la: " << ps2.ts << "/" << ps2.ms<<endl;
	}
	else if (val1 == val2) cout << "Hai phan so bang nhau"<<endl;
	else {
		cout << "Phan so lon nhat la: " << ps1.ts << "/" << ps1.ms<<endl;
	}

}
int main()
{
PhanSo ps1,ps2;
NhapPhanSo(ps1);
NhapPhanSo(ps2);
Sosanh(ps1,ps2);
system("pause");
}
