/*4. Nhập vào ĐTB của 1 học sinh. In ra màn hình kết quả xếp loại như sau:
• 0 ≤ ĐTB < 5: Yếu
• 5 ≤ ĐTB < 7: TB
• 7 ≤ ĐTB < 8: Khá
• 8 ≤ ĐTB < 9: Giỏi
• 9 ≤ ĐTB ≤ 10: Xuất sắc
- Input: đtb
- Output: kết quả xếp loại
- GT: Đặt điều kiện theo đề bài
 */

#include <iostream>

using namespace std;

int main()
{
    float dtb;
    cout << "Nhap dtb: ";
    cin >> dtb;
    while(dtb<0||dtb>10){ cout << "Loi. Nhap lai dtb: ";
    cin >>dtb;}
    if(dtb>=0 && dtb <5) {cout << " Yeu "; }
    else if( dtb<7) {cout << "TB";}
    else if( dtb <8) {cout << "Kha";}
    else if( dtb<9 ) {cout << "Gioi";}
    else cout<<  " Xuat xac ";
}
