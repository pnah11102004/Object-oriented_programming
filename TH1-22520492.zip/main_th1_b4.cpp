/*4. Viết chương trình nhập vào một ngày. Tìm ngày kế tiếp và xuất kết quả.
-Input: 1 ngày bất kì
-Output: Ngày kế tiếp
-GT: + Nhập 1 ngày bất kì
     + Đặt điều kiện số ngày của từng tháng thuộc năm nhuận hay năm bình thường
     + Tìm và xuất ngày kế tiếp
*/
#include <iostream>

using namespace std;
//khai bao kieu du lieu
typedef struct ngay
{
    int dd,mm,yyyy;
}n;
//nhap ngay bat ki
void Nhap(n& x,int& max)
{
    cout<<"Nhap ngay: ";
    cin >>x.dd;
    cout<<"Nhap thang: ";
    cin >> x.mm;
    cout << "Nhap nam: ";
    cin >> x.yyyy;
    switch(x.mm)
    {
    case 1: case 3: case 5: case 7: case 8: case 10: case 12:
        max=31;
        break;
    case 4: case 6: case 9: case 11:
        max=30;
        break;
    case 2:
        if(x.yyyy%400==0||(x.yyyy%4==0&&x.yyyy%100!=0))
            max=29;
        else max=28;
        break;
     default: max=0;
    }
    if(max==0||x.yyyy<1||(max!=0 &&(x.dd>max||x.dd<1)))
        {
		cout << "Ngay thanh nam khong hop le, vui long nhap lai:" << '\n';
		Nhap(x, max);
	}
}
void Nextday(n x, n &y, int a)
{
    if(x.dd<a)
    {
        y.dd=x.dd+1;
        y.mm=x.mm;
        y.yyyy=x.yyyy;
    }
    else{
        if (x.mm !=12)
        {
            y.dd=1;
            y.mm=x.mm+1;
            y.yyyy=x.yyyy;
        }
        else
        {
            y.dd=1;
            y.mm=1;
            y.yyyy=x.yyyy+1;
        }
    }
}
int main()
{
    n d1,d2;
    int max;
    Nhap(d1,max);
    Nextday(d1,d2,max);
    cout<< "Ngay ke tiep la: "<< d2.dd<<"/"<<d2.mm<<"/"<<d2.yyyy;
    return 0;
}
