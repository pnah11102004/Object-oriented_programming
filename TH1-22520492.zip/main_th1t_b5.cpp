/*5. Nhập vào username và password. Nếu nhập sai quá 3 lần thì in thông báo lỗi, ngược lại hiển
thị câu chào username
- Input : username và password
- Output: Đúng thì chào username, sai thì báo lỗi.
- GT: - Nhap thong tin
      - So sanh thông tin nhập và thông tin đúng
      - Nếu đúng -> Chào username
            Sai <= 3 lần -> Nhập lại
            Sai trên 3 lần  -> Lỗi
*/
#include <iostream>
#include <string>



using namespace std;

int main()
{
    string user,pass;
    int a=0;
    const int max_a=3;
    while(a<max_a) {
    cout<<"Nhap username: ";
    cin >> user;
    cout << "Nhap password: ";
    cin >> pass;
    if (user=="user" && pass=="123123") {
        cout << "Xin chao " << user <<endl;
        return 0;
    }
    else {
        a++;
        cout << "Loi.Ban con "<<3-a<<"lan nhap lai." << endl;

}
    }
cout << "Ban da nhap sai qua 3. Loi." << endl;
return 0;
}

