/*5. Viết chương trình nhập họ tên, điểm toán, điểm văn của một học sinh. Tính điểm
trung bình và xuất kết quả.
-Input: Họ tên, điểm toán, điểm văn
-Output: Điểm trung bình, xuất kết quả.
-GT:    + Nhập dữ liệu
        + Đtb=(văn+toán)/2
        + Xuất kết quả
        */
#include <iostream>
#include<cmath>

using namespace std;
//Khai bao kieu du lieu
 struct HocSinh
{
    string hoten;
    float dtb;//diem trung binh
    float dt;//diem toan
    float dv;//diem van
};
typedef struct HocSinh HS;
//Nhap du lieu
void Nhap(HS &a)
{
    cout<<"Nhap ten hoc sinh: ";
    cin >> a.hoten;
    cout<<"Nhap diem toan: ";
    cin >> a.dt;
    cout<< "Nhap diem van: ";
    //đặt điều kiện cho dữ liệu
    cin >> a.dv;
    if(a.dt<0||a.dt>10) {cout<< "Du lieu sai. Xin nhap lai diem toan: ";
    cin >> a.dt;}
    if(a.dv<0||a.dv>10) {cout<< "Du lieu sai. Xin nhap lai diem van: ";
    cin >> a.dv;}

}
//Tính đtb và xuất
void Tinhdtb(HS a)
{
    a.dtb=(a.dv+a.dt)/2;
    cout<< " Diem trung binh cua "<<a.hoten<<" la: "<<a.dtb;
}
int main()
{
    HS a;
    Nhap(a);
    Tinhdtb(a);
    return 0;
}
