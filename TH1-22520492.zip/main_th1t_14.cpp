/* 14. Viết chương trình mô phỏng trò chơi oẳn tù tì với máy.
-Input: Kéo or búa or bao
-Output: Kéo or búa or bao
-GT: +Khai báo lưu thông tin
    + Kiểm tra kết quả
    + Tạo lựa chọn cho máy qua số 1 2 3
    + Xuất lựa chọn của người chơi của máy và kết quả
*/
#include <iostream>
#include <cstdlib>
#include <ctime>
using namespace std;

// Khai báo struct để lưu trữ thông tin về người chơi và máy
struct Player {
    string name;
    string choice;
};

// Hàm kiểm tra kết quả của trò chơi
int checkResult(string p1, string p2) {
    if (p1 == "bao" && p2 == "bua") {
        return 1;
    } else if (p1 == "bua" && p2 == "keo") {
        return 1;
    } else if (p1 == "keo" && p2 == "bao") {
        return 1;
    } else if (p1 == p2) {
        return 0;
    } else {
        return -1;
    }
}

int main() {
    // Khai báo biến và lưu tên người chơi
    Player player;
    cout << "Nhap ten cua ban: ";
    cin >> player.name;

    // Khai báo biến và tạo lựa chọn cho máy
    Player computer;
    srand(time(NULL));
    int choice = rand() % 3;
    if (choice == 0) {
        computer.choice = "bao";
    } else if (choice == 1) {
        computer.choice = "bua";
    } else {
        computer.choice = "keo";
    }

    // Nhập lựa chọn của người chơi
    cout << "Nhap lua chon cua ban (bao/bua/keo): ";
    cin >> player.choice;

    // In ra lựa chọn của cả hai và kết quả
    cout << "Ban chon: " << player.choice << endl;
    cout << "May chon: " << computer.choice << endl;

    int result = checkResult(player.choice, computer.choice);

    if (result == 0) {
        cout << "Hoa!" << endl;
    } else if (result == 1) {
        cout << "Ban thang!" << endl;
    } else {
        cout << "May thang!" << endl;
    }

    return 0;
}
