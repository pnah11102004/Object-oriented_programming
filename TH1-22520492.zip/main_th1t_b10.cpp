/*10. Nhập giờ vào ca, giờ ra ca của 1 công nhân. Tính và in ra tiền lương ngày của công nhân đó.
Biết rằng:
• Giờ vào ca sớm nhất là 6h và giờ ra ca trễ nhất là 18h.
• Tiền công trước 12h là 6000đ/giờ và sau 12h là 7500đ/giờ.
-Input: giờ vào , giờ ra
-Output: Số tiền Lương c
-Gt: + khai báo biến để lưu thông tin
    + ca trước 6h thì giờ vào ca giới hạn tối thiểu là 6h
    + ca ra muộn hơn 18h thì giờ ra ca sẽ giới hạn tối đa là 18h
    + sử dụng điều kiện bài toán rồi tính
*/
#include <iostream>
using namespace std;

struct Time {
    int hour;
    int minute;
};

int main() {
    Time inTime, outTime;
    cout << "Nhap gio vao ca: ";
    cin >> inTime.hour >> inTime.minute; // Nhập giờ nhập phút
    cout << "Nhap gio ra ca: ";
    cin >> outTime.hour >> outTime.minute; //Nhập giờ và phút

    // Xác định giờ vào/ra ca nếu nó trước hoặc sau thời gian cho phép
    if (inTime.hour < 6) {
        inTime.hour = 6;
        inTime.minute = 0;
    }
    if (outTime.hour > 18) {
        outTime.hour = 18;
        outTime.minute = 0;
    }

    // Tính số giờ công
    float workHours;
    if (outTime.hour < 12) {
        workHours = (outTime.hour - inTime.hour) + (outTime.minute - inTime.minute) / 60.0;
    } else if (inTime.hour >= 12) {
        workHours = (outTime.hour - inTime.hour) + (outTime.minute - inTime.minute) / 60.0;
    } else {
        workHours = (12 - inTime.hour) + (inTime.minute / 60.0) + (outTime.hour - 12) + (outTime.minute / 60.0);
    }

    // Tính tiền lương
    float salary;
    if (outTime.hour < 12) {
        salary = workHours * 6000;
    } else {
        salary = (12 - inTime.hour) * 6000 + (workHours - (12 - inTime.hour)) * 7500;
    }

    cout << "So gio cong: " << workHours << endl;
    cout << "Tien luong: " << salary << " VND" << endl;

    return 0;
}
