#pragma once
#include <iostream>
#include <stdexcept>
using namespace std;
class CDate
{
private:
	int ngay, thang, nam;
	static int dem;
public:
	~CDate();
	CDate();
	CDate(int);
	CDate(int, int);
	CDate(int, int, int);
	int GetNgay() const;
	int GetThang() const;
	int GetNam() const;
	void SetNgay(int);
	void SetThang(int);
	void SetNam(int);
	void SetNgaySinh(int, int, int);
	friend istream& operator >> (istream&, CDate&);
	friend ostream& operator << (ostream&, CDate&);
	bool KTHopLe()const;
	CDate operator++();
	CDate operator++(int);
	CDate operator--();
	CDate operator--(int);


};
