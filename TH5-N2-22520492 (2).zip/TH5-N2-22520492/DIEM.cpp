#include "DIEM.h"
#include <cmath>

DIEM::DIEM() : x(0), y(0) {}

DIEM::DIEM(float x, float y) : x(x), y(y) {}

DIEM::~DIEM() {}

void DIEM::set(float x, float y) {
    this->x = x;
    this->y = y;
}

float DIEM::getX() const {
    return x;
}

float DIEM::getY() const {
    return y;
}

void DIEM::nhap() {
    cout << "Nhap hoanh do: ";
    cin >> x;
   cout << "Nhap tung do: ";
    cin >> y;
}

void DIEM::xuat() {
    cout << "(" << x << ", " << y << ")";
}

float DIEM::khoangCach(const DIEM& other) const {
    float dx = x - other.x;
    float dy = y - other.y;
    return sqrt(dx * dx + dy * dy);
}

DIEM DIEM::doiXung() const {
    return DIEM(-x, -y);
}

std::istream& operator>>(std::istream& is, DIEM& point) {
    float x, y;
    is >> x >> y;
    point.set(x, y);
    return is;
}


ostream& operator<<(ostream& os, const DIEM& point) {
    os << "(" << point.getX() << ", " << point.getY() << ")";
    return os;
}
