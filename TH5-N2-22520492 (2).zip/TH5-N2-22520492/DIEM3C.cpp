#include "DIEM3C.h"
#include <cmath>

DIEM3C::DIEM3C() : DIEM(), z(0) {}

DIEM3C::DIEM3C(float x, float y, float z) : DIEM(x, y), z(z) {}

DIEM3C::~DIEM3C() {}

void DIEM3C::setZ(float z) {
    this->z = z;
}

float DIEM3C::getZ() const {
    return z;
}

bool DIEM3C::trungDiem(const DIEM3C& other) const {
    return (x == other.x && y == other.y && z == other.z);
}

void DIEM3C::diChuyen(float dx, float dy, float dz) {
    x += dx;
    y += dy;
    z += dz;
}

float DIEM3C::khoangCach(const DIEM3C& other) const {
    float dx = x - other.x;
    float dy = y - other.y;
    float dz = z - other.z;
    return sqrt(dx * dx + dy * dy + dz * dz);
}

DIEM3C DIEM3C::doiXung() const {
    return DIEM3C(-x, -y, -z);
}

void DIEM3C::nhap() {
    DIEM::nhap();
    cout << "Nhap cao do: ";
    cin >> z;
}

void DIEM3C::xuat() {
    DIEM::xuat();
    cout << ", " << z;
}

float DIEM3C::chuViTamGiac(const DIEM3C& b, const DIEM3C& c) const {
    float ab = khoangCach(b);
    float bc = b.khoangCach(c);
    float ca = c.khoangCach(*this);
    return ab + bc + ca;
}

float DIEM3C::dienTichTamGiac(const DIEM3C& b, const DIEM3C& c) const {
    float ab = khoangCach(b);
    float bc = b.khoangCach(c);
    float ca = c.khoangCach(*this);
    float p = (ab + bc + ca) / 2;
    return sqrt(p * (p - ab) * (p - bc) * (p - ca));
}

istream& operator>>(istream& is, DIEM3C& point) {
    is >> point.x >> point.y >> point.z;
    return is;
}

ostream& operator<<(ostream& os, const DIEM3C& point) {
    os << "(" << point.x;
    os << ", " << point.y << ", " << point.z << ")";
    return os;
}
