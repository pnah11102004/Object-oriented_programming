#include"CDate.h"
int main() {
    CDate day, d;
    int chon;
    do {
        cout << "-----------------------------MENU-------------------------\n";
        cout << "1. Nhap.\n";
        cout << "2. Xuat.\n";
        cout << "3. Xuat ngay hom sau.\n";
        cout << "4. Xuat ngay hom truoc.\n";
        cout << "0. KT chuong trinh.\n";
        cout << "---------------------------------------------------------\n";
        cout << "Ban chon: ";
        cin >> chon;
        switch (chon) {
        case 0:
            cout << "Dang thoat chuong trinh...\n";
            break;
        case 1:
            cin >> day;
            break;
        case 2:
            cout << day << endl;
            break;
        case 3:
            d = ++day;
            cout << "Ngay hom sau la: " << d << endl;
            break;
        case 4:
            d = --day;
            cout << "Ngay hom truoc la: " << d << endl;
            break;
        }
    } while (chon != 0);

    return 0;
}