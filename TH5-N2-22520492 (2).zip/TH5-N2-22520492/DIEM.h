#ifndef DIEM_H_INCLUDED
#define DIEM_H_INCLUDED

#include <iostream>
using namespace std;
class DIEM {
protected:
    float x;
    float y;

public:
    DIEM();
    DIEM(float x, float y);
    virtual ~DIEM();

    void set(float x, float y);
    float getX() const;
    float getY() const;
    void nhap();
    void xuat();

    float khoangCach(const DIEM& other) const;
    DIEM doiXung() const;
};

istream& operator>>(istream& is, DIEM& point);
ostream& operator<<(ostream& os, const DIEM& point);



#endif // DIEM_H_INCLUDED
