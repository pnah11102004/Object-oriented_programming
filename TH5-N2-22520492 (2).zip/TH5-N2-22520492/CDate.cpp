﻿#include"CDate.h"
int CDate::dem = 0;
CDate :: ~CDate()
{
	dem--;
}
CDate::CDate() {
	// Khởi tạo ngày hiện hành
	time_t now = time(0);
	tm ltm;
	localtime_s(&ltm, &now);
	ngay = ltm.tm_mday;
	thang = ltm.tm_mon + 1;
	nam = ltm.tm_year + 1900;
}

CDate::CDate(int d) : CDate() {
	// Khởi tạo ngày của tháng và năm hiện hành
	if (KTHopLe())
		ngay = d;
	else
		throw std::invalid_argument("Ngay khong hop le!");
}

CDate::CDate(int d, int m) : CDate() {
	// Khởi tạo ngày tháng của năm hiện hành
	if (KTHopLe()) {
		ngay = d;
		thang = m;
	}
	else {
		throw std::invalid_argument("Ngay hoac thang khong hop le!");
	}
}

CDate::CDate(int d, int m, int y) {
	// Khởi tạo ngày tháng năm ứng với 3 tham số
	if (KTHopLe()) {
		ngay = d;
		thang = m;
		nam = y;
	}
	else {
		throw std::invalid_argument("Ngay khong hop le!");
	}
}
//CDate::CDate() :ngay(12), thang(05), nam(2023)
//{
//
//	dem++;
//}
//CDate::CDate(int ngay) : ngay(ngay), thang(05), nam(2023)
//{
//	dem++;
//}
//CDate::CDate(int ngay, int thang) : ngay(ngay), thang(thang), nam(2023)
//{
//	dem++;
//}
//CDate::CDate(int ngay, int thang, int nam) : ngay(ngay), thang(thang), nam(nam)
//{
//	dem++;
//}
int CDate::GetNgay() const
{
	return ngay;
}
int CDate::GetThang() const
{
	return thang;
}
int CDate::GetNam() const
{
	return nam;
}
void CDate::SetNgay(int ngay)
{
	this->ngay = ngay;
	while (1)
	{
		if (thang == 2)
		{
			if (nam % 4 == 0 && nam % 100 != 0 || nam % 400 == 0)
			{
				if (ngay > 0 && ngay <= 29)
					break;
			}
			else
			{
				if (ngay > 0 && ngay <= 28)
					break;
			}
		}
		else
		{
			if (ngay > 0 && ngay < 31)
				break;
		}

	}

}
void CDate::SetThang(int thang)
{
	while (1)
	{
		this->thang = thang;
		if (thang <= 0 && thang > 12)
		{
			break;
		}
	}

}
void CDate::SetNam(int nam)
{
	while (1)
	{
		this->nam = nam;
		if (nam < 0 && nam > 2023)
		{
			break;
		}
	}

}
void CDate::SetNgaySinh(int ngay, int thang, int nam)
{

	while (1)
	{
		this->ngay = ngay;
		if (thang == 2)
		{
			if (nam % 4 == 0 && nam % 100 != 0 || nam % 400 == 0)
			{
				if (ngay > 0 && ngay <= 29)
					break;
			}
			else
			{
				if (ngay > 0 && ngay <= 28)
					break;
			}
		}
		else
		{
			if (ngay > 0 && ngay < 31)
				break;
		}

	}
	while (1)
	{
		this->thang = thang;
		if (thang <= 0 && thang > 12)
		{
			break;
		}
	}
	while (1)
	{
		this->nam = nam;
		if (nam < 0 && nam > 2023)
		{
			break;
		}
	}
}
bool CDate::KTHopLe() const
{
	if (nam < 0 || thang < 1 || thang > 12)
	{
		return false;
	}
	int ngaymax = 31;
	if (thang == 4 || thang == 6 || thang == 9 || thang == 11)
		ngaymax = 30;
	else if (thang == 2)
	{
		ngaymax = (nam % 4 == 0 && (nam % 100 != 0 || nam % 400 == 0)) ? 29 : 28;
	}
	return (ngay >= 1 && ngay <= ngaymax);
}
istream& operator >> (istream& is, CDate& d)
{
	do
	{
		cout << "Nhap ngay: "; cin >> d.ngay;
		cout << "Nhap thang: "; cin >> d.thang;
		cout << "Nhap nam: "; cin >> d.nam;
	} while (!d.KTHopLe());
	return is;
}
ostream& operator<<(ostream& os, CDate& d)
{
	os << d.ngay << "/" << d.thang << "/" << d.nam;
	return os;
}
CDate CDate::operator++()
{
	ngay++;
	if (!KTHopLe())
	{
		ngay = 1;
		thang++;
		if (!KTHopLe())
		{
			thang = 1;
			nam++;
		}
	}
	return *this;
}

CDate CDate::operator++(int)
{
	CDate tmp(*this);
	operator++();
	return tmp;
}

CDate CDate::operator--()
{
	ngay--;
	if (ngay < 1)
	{
		thang--;
		if (thang < 1)
		{
			nam--;
			thang = 12;
		}
		ngay = 31;
		if (thang == 4 || thang == 6 || thang == 9 || thang == 11)
			ngay = 30;
		else if (thang == 2)
		{
			if (nam % 4 == 0 && (nam % 100 != 0 || nam % 400 == 0))
				ngay = 29;
			else
				ngay = 28;
		}
	}
	return *this;
}

CDate CDate::operator--(int)
{
	CDate tmp(*this);
	operator--();
	return tmp;
}