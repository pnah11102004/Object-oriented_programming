#include <iostream>
#include "DIEM.h"
#include "DIEM3C.h"

int main() {
    DIEM diem2D1;
    cout << "Nhap toa do diem 2D 1:\n";
    cin >> diem2D1;

    DIEM diem2D2;
    cout << "Nhap toa do diem 2D 2:\n";
    cin >> diem2D2;

    cout << "Diem 2D 1: " << diem2D1 << endl;
    cout << "Diem 2D 2: " << diem2D2 << endl;
    cout << "Khoang cach giua hai diem 2D: " << diem2D1.khoangCach(diem2D2) << endl;

    DIEM3C diem3D1;
    cout << "Nhap toa do diem 3D 1:\n";
    cin >> diem3D1;

    DIEM3C diem3D2;
    cout << "Nhap toa do diem 3D 2:\n";
    cin >> diem3D2;

    cout << "Diem 3D 1: " << diem3D1 << endl;
    cout << "Diem 3D 2: " << diem3D2 << endl;
    cout << "Khoang cach giua hai diem 3D: " << diem3D1.khoangCach(diem3D2) << endl;

    return 0;
}
