#ifndef CTIME_H_INCLUDED
#define CTIME_H_INCLUDED
#pragma once
#include <iostream>
#include<math.h>
class CTime {
private:
    int hour,minute, second;

public:
    CTime();
    CTime(int hour, int minute, int second);
    ~CTime();

    int getHour() const;
    int getMinute() const;
    int getSecond() const;

    void setHour(int hour);
    void setMinute(int minute);
    void setSecond(int second);

    CTime operator+(int seconds) const;
    CTime operator-(int seconds) const;
    CTime operator++();
    CTime operator++(int);
    CTime operator--();
    CTime operator--(int);

    friend std::ostream& operator<<(std::ostream& os, const CTime& time);
    friend std::istream& operator>>(std::istream& is, CTime& time);
    friend CTime operator-(const CTime& time1, const CTime& time2);
};

class CTimeSpan {
private:
    int m_seconds;

public:
    CTimeSpan();
    CTimeSpan(int seconds);
    ~CTimeSpan();

    int getSeconds() const;

    void setSeconds(int seconds);

    friend std::ostream& operator<<(std::ostream& os, const CTimeSpan& timeSpan);
};


#endif
