#include "INTEGER.h"

INTEGER::INTEGER() {
    value = 0;
}

INTEGER::INTEGER(int val) {
    value = val;
}

int INTEGER::getValue() {
    return value;
}

void INTEGER::setValue(int val) {
    value = val;
}

INTEGER INTEGER::operator+(INTEGER other) {
    INTEGER result(value + other.getValue());
    return result;
}

INTEGER INTEGER::operator-(INTEGER other) {
    INTEGER result(value - other.getValue());
    return result;
}

INTEGER INTEGER::operator*(INTEGER other) {
    INTEGER result(value * other.getValue());
    return result;
}

INTEGER INTEGER::operator/(INTEGER other) {
    INTEGER result(value / other.getValue());
    return result;
}

INTEGER INTEGER::operator%(INTEGER other) {
    INTEGER result(value % other.getValue());
    return result;
}

INTEGER INTEGER::operator=(INTEGER other) {
    value = other.getValue();
    return *this;
}
