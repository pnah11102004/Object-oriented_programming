#ifndef INTEGER_H_INCLUDED
#define INTEGER_H_INCLUDED


class INTEGER {
private:
    int value;

public:
    INTEGER();  // Constructor mặc định
    INTEGER(int val);  // Constructor chấp nhận một giá trị int
    int getValue();  // Trả về giá trị của INTEGER
    void setValue(int val);  // Thiết lập giá trị cho INTEGER
    INTEGER operator+(INTEGER other);  // Phép cộng INTEGER với một INTEGER khác
    INTEGER operator-(INTEGER other);  // Phép trừ INTEGER với một INTEGER khác
    INTEGER operator*(INTEGER other);  // Phép nhân INTEGER với một INTEGER khác
    INTEGER operator/(INTEGER other);  // Phép chia INTEGER cho một INTEGER khác
    INTEGER operator%(INTEGER other);  // Phép chia lấy phần dư INTEGER cho một INTEGER khác
    INTEGER operator=(INTEGER other);  // Gán giá trị INTEGER bằng một INTEGER khác
};




#endif // INTEGER_H_INCLUDED
