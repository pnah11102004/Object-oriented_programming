#ifndef B7_H_INCLUDED
#define B7_H_INCLUDED

#include <vector>

class Polynomial {
private:
    std::vector<double> coefficients; // Mảng chứa các hệ số của đa thức
    int degree; // Bậc của đa thức

public:
    Polynomial(); // Constructor mặc định
    Polynomial(const std::vector<double>& coeffs, int deg); // Constructor với tham số
    void setCoefficient(int deg, double coeff); // Thiết lập hệ số cho một bậc cụ thể
    double getCoefficient(int deg) const; // Lấy hệ số của một bậc cụ thể
    int getDegree() const; // Lấy bậc của đa thức
    void add(const Polynomial& other); // Phép cộng hai đa thức
    void subtract(const Polynomial& other); // Phép trừ hai đa thức
    void multiply(const Polynomial& other); // Phép nhân hai đa thức
    void divide(const Polynomial& other); // Phép chia hai đa thức
    Polynomial derivative() const; // Tính đạo hàm của đa thức
    Polynomial integral() const; // Tính nguyên hàm của đa thức
    void print() const; // In ra đa thức
};

#endif
