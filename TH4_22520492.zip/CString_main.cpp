#include <iostream>
#include "CString.h"

int main() {
    // Test constructors
    CString str1; // Default constructor
    CString str2("Hello"); // Constructor with C-style string parameter
    CString str3 = str2; // Copy constructor

    // Test member functions
    std::cout << "Length of str2: " << str2.GetLength() << std::endl;
    std::cout << "str2: " << str2.GetString() << std::endl;

    // Test operators
    CString str4 = str2 + str3; // Concatenation operator
    std::cout << "str4: " << str4.GetString() << std::endl;

    if (str2 == str3) { // Equality operator
        std::cout << "str2 is equal to str3" << std::endl;
    }

    if (str2 != str4) { // Inequality operator
        std::cout << "str2 is not equal to str4" << std::endl;
    }

    // Test assignment operator
    str1 = str2;
    std::cout << "str1: " << str1.GetString() << std::endl;

    return 0;
}
