#ifndef SOPHUC_H_INCLUDED
#define SOPHUC_H_INCLUDED
#include<iostream>
using namespace std;
class SOPHUC {
private:
    int thuc,ao;
    static int dem;
public:
    ~SOPHUC();
    SOPHUC();
    SOPHUC(int);
    SOPHUC(int,int);
    SOPHUC(const SOPHUC&);
    void Nhap();
    int GetThuc() const;
    int GetAo() const;
    static int GetDem();
    void SetThuc(int);
    void SetAo(int);
    void SetSP(int,int);
    friend SOPHUC operator+(const SOPHUC&,const SOPHUC&);
    friend SOPHUC operator-(const SOPHUC&,const SOPHUC&);
    friend SOPHUC operator*(const SOPHUC&,const SOPHUC&);
    friend SOPHUC operator/(const SOPHUC&,const SOPHUC&);
    SOPHUC operator++();
    SOPHUC operator++(int);
    SOPHUC operator--();
    SOPHUC operator--(int);
    friend bool operator==(const SOPHUC&, const SOPHUC&);
    friend bool operator!=(const SOPHUC&, const SOPHUC&);
    friend bool operator<(const SOPHUC&, const SOPHUC&);
    friend bool operator<=(const SOPHUC&, const SOPHUC&);
    friend bool operator>(const SOPHUC&, const SOPHUC&);
    friend bool operator>=(const SOPHUC&, const SOPHUC&);
    friend istream& operator>>(istream&,SOPHUC&);
    friend ostream& operator<<(ostream&, SOPHUC&);


};


#endif // SOPHUC_H_INCLUDED
