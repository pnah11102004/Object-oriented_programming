#include <iostream>
#include "CTime.h"

using namespace std;

int main() {
    CTime t1(10, 30, 0);
CTime t2(12, 0, 0);
std::cout << t2 - t1 << std::endl; // 1:30:0
std::cout << ++t1 << std::endl; // 10:30:1
std::cout << t1-- << std::endl; // 10:30:1
std::cout << t1 << std::endl; // 10:30:0
std::cout << t1 + 70 << std::endl; // 10:31:10
std::cout << t1 - 70 << std::endl; // 10:28:50
CTimeSpan ts(180);
std::cout << ts << std::endl; // 180 seconds
return 0;
}
