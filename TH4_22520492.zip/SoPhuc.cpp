#include"SoPhuc.h"
int SOPHUC::dem=0;
SOPHUC::~SOPHUC()
{
    dem--;
}
SOPHUC::SOPHUC(): thuc(1), ao(0)
{
    dem++;
}
SOPHUC::SOPHUC(int ao): thuc(1), ao(ao)
{
    dem++;
}
SOPHUC::SOPHUC(int thuc,ao): thuc(thuc), ao(ao)
{
    dem++;
}
SOPHUC::SOPHUC(const SOPHUC& sp): thuc(sp.thuc), ao(sp.ao)
{
    dem++;
}
void SOPHUC::Nhap()
{
    cout<<"Nhap phan thuc:";
    cin>>thuc;
    ao=0;
    cout<<"Phan ao = 0";

}
int SOPHUC::GetAo() const
{
    return ao;
}
int SOPHUC::GetThuc() const
{
    return thuc;
}
int SOPHUC::GetDem() const
{
    return dem;
}
void SOPHUC::SetAo(int ao)
{
    this->ao=ao;
}
void SOPHUC::SetThuc(int thuc)
{
    this->thuc=thuc;
}
void SOPHUC::SetSP(int thuc,int ao)
{
    this->thuc=thuc;
    this->ao=ao;
}
SOPHUC operator+(const SOPHUC% sp1,const SOPHUC& sp2)
{
    return SOPHUC(sp1.thuc+sp2.thuc, sp1.ao+sp2.ao);
}
SOPHUC operator-(const SOPHUC% sp1,const SOPHUC& sp2)
{
    return SOPHUC(sp1.thuc-sp2.thuc, sp1.ao-sp2.ao);
}
SOPHUC operator*(const SOPHUC% sp1,const SOPHUC& sp2)
{
    return SOPHUC(sp1.thuc*sp2.thuc, sp1.ao*sp2.ao);
}
SOPHUC operator/(const SOPHUC% sp1,const SOPHUC& sp2)
{
    return SOPHUC(sp1.thuc/sp2.thuc, sp1.ao/sp2.ao);
}
SOPHUC SOPHUC::operator++()
{

    thuc++;
    return *this;

}
SOPHUC SOPHUC::operator++(int)
{
    SOPHUC sptam(thuc,ao);
    thuc++;
    return sptam;

}
SOPHUC SOPHUC::operator--()
{

    thuc--;
    return *this;

}
SOPHUC SOPHUC::operator--(int)
{
    SOPHUC sptam(thuc,ao);
    thuc--;
    return sptam;

}
SOPHUC::operator double() const
{
    return (double)thuc +ao.i;
}
bool operator==(const SOPHUC& sp1,const SOPHUC& sp2)
{
    return (double)sp1==(double)sp2;
}
bool operator!=(const SOPHUC& sp1,const SOPHUC& sp2)
{
    return (double)sp1!=(double)sp2;
}
bool operator<(const SOPHUC& sp1,const SOPHUC& sp2)
{
    return (double)sp1<(double)sp2;
}
bool operator<=(const SOPHUC& sp1,const SOPHUC& sp2)
{
    return (double)sp1<=(double)sp2;
}
bool operator>(const SOPHUC& sp1,const SOPHUC& sp2)
{
    return (double)sp1>(double)sp2;
}
bool operator>=(const SOPHUC& sp1,const SOPHUC& sp2)
{
    return (double)sp1>=(double)sp2;
}
istream& operator>>(istream& is, SOPHUC& sp)
{
    cout<<"Nhap so thuc:";
    is>>thuc;
    cout<<"Phan ao=0";

}
ostream& operator<<(ostream& os, SOPHUC& sp)
{
    return os;
}
