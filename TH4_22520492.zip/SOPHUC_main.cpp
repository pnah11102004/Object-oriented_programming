#include <iostream>
#include"SoPhuc.h"
using namespace std;

int main()
{
   SOPHUC sp1,sp2(2),sp3(5,0),A;
   cout<<"sp1="<<sp1<<endl<<"sp2="<<sp2<<endl<<"sp3="<<sp3<<endl;
   cout<<"Nhap lai sp1, sp2, sp3: "<<endl;
   cin>>sp1>>sp2>>sp3;
   A=(SOPHUC)1+ ++sp2 +sp3-- -(SOPHUC)2;
   cout<<"A="<<A<<endl<<"sp2="<<sp2<<endl<<"sp3="<<sp3<<endl;
   SOPHUC B=sp3+(SOPHUC)2;
   cout<<"B="<<B<<endl;
   if(A==B)
    cout<<A<<"=="<<B<<endl;
   else
    cout<<A<<"!="<<B<<endl;
   }
