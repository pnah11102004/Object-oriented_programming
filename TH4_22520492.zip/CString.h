#ifndef CSTRING_H_INCLUDED
#define CSTRING_H_INCLUDED


class CString {
public:
    // Constructors
    CString(); // Default constructor
    CString(const char* str); // Constructor with a C-style string parameter
    CString(const CString& other); // Copy constructor

    // Destructor
    ~CString();

    // Member functions
    int GetLength() const; // Get the length of the string
    const char* GetString() const; // Get the C-style string representation

    // Overloaded operators
    CString& operator=(const CString& other); // Assignment operator
    CString operator+(const CString& other) const; // Concatenation operator
    bool operator==(const CString& other) const; // Equality operator
    bool operator!=(const CString& other) const; // Inequality operator

private:
    char* m_data; // Pointer to the dynamically allocated string
};




#endif // CSTRING_H_INCLUDED
