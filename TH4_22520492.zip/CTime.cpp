#include "CTime.h"


CTime::CTime() : m_hour(0), m_minute(0), m_second(0) {}

CTime::CTime(int hour, int minute, int second) : m_hour(hour), m_minute(minute), m_second(second) {}

CTime::~CTime() {}

int CTime::getHour() const {
    return m_hour;
}

int CTime::getMinute() const {
    return m_minute;
}

int CTime::getSecond() const {
    return m_second;
}

void CTime::setHour(int hour) {
    m_hour = hour;
}

void CTime::setMinute(int minute) {
    m_minute = minute;
}

void CTime::setSecond(int second) {
    m_second = second;
}

CTime CTime::operator+(int seconds) const {
    int totalSeconds = m_hour * 3600 + m_minute * 60 + m_second + seconds;
    int hour = totalSeconds / 3600;
    int minute = (totalSeconds % 3600) / 60;
    int second = totalSeconds % 60;
    return CTime(hour, minute, second);
}

CTime CTime::operator-(int seconds) const {
    int totalSeconds = m_hour * 3600 + m_minute * 60 + m_second - seconds;
    int hour = totalSeconds / 3600;
    int minute = (totalSeconds % 3600) / 60;
    int second = totalSeconds % 60;
    return CTime(hour, minute, second);
}

CTime CTime::operator++() {
    ++m_second;
    if (m_second >= 60) {
        m_second = 0;
        ++m_minute;
        if (m_minute >= 60) {
            m_minute = 0;
            ++m_hour;
            if (m_hour >= 24) {
                m_hour = 0;
            }
        }
    }
    return *this;
}

CTime CTime::operator++(int) {
    CTime temp(*this);
    ++(*this);
    return temp;
}

CTime CTime::operator--() {
    --m_second;
    if (m_second < 0) {
        m_second = 59;
        --m_minute;
    if (m_minute < 0) {
m_minute = 59;
--m_hour;
if (m_hour < 0) {
m_hour = 23;
}
}
return *this;
}

CTime CTime::operator--(int) {
CTime temp(*this);
--(*this);
return temp;
}

std::ostream& operator<<(std::ostream& os, const CTime& time) {
os << time.m_hour << ":" << time.m_minute << ":" << time.m_second;
return os;
}

std::istream& operator>>(std::istream& is, CTime& time) {
char colon1, colon2;
is >> time.m_hour >> colon1 >> time.m_minute >> colon2 >> time.m_second;
return is;
}

CTime operator-(const CTime& time1, const CTime& time2) {
int seconds1 = time1.m_hour * 3600 + time1.m_minute * 60 + time1.m_second;
int seconds2 = time2.m_hour * 3600 + time2.m_minute * 60 + time2.m_second;
int diffSeconds = seconds1 - seconds2;
if (diffSeconds < 0) {
diffSeconds += 86400;
}
int hour = diffSeconds / 3600;
int minute = (diffSeconds % 3600) / 60;
int second = diffSeconds % 60;
return CTime(hour, minute, second);
}

CTimeSpan::CTimeSpan() : m_seconds(0) {}

CTimeSpan::CTimeSpan(int seconds) : m_seconds(seconds) {}

CTimeSpan::~CTimeSpan() {}

int CTimeSpan::getSeconds() const {
return m_seconds;
}

void CTimeSpan::setSeconds(int seconds) {
m_seconds = seconds;
}

std::ostream& operator<<(std::ostream& os, const CTimeSpan& timeSpan) {
os << timeSpan.m_seconds << " seconds";
return os;
}
