#include <iostream>
#include "CDay.h"

int main() {
    CDate date1(10, 5, 2023);
    CDate date2(15, 5, 2023);

    std::cout << "Date 1: " << date1 << std::endl;
    std::cout << "Date 2: " << date2 << std::endl;

    // Add 3 days to date1
    CDate date3 = date1 + 3;
    std::cout << "Date 3 (date1 + 3): " << date3 << std::endl;

    // Subtract 2 days from date2
    CDate date4 = date2 - 2;
    std::cout << "Date 4 (date2 - 2): " << date4 << std::endl;

    // Increment date1 by one day
    ++date1;
    std::cout << "Date 1 (after increment): " << date1 << std::endl;

    // Decrement date2 by one day
    --date2;
    std::cout << "Date 2 (after decrement): " << date2 << std::endl;

    // Calculate the difference between date1 and date2
    int difference = date2 - date1;
    std::cout << "Difference between date1 and date2: " << difference << " days" << std::endl;

    return 0;
}
