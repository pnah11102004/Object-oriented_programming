#include "CDay.h"

CDate::CDate() : day(1), month(1), year(1900) {}

CDate::CDate(int d, int m, int y) : day(d), month(m), year(y) {}

int CDate::getDay() const {
    return day;
}

int CDate::getMonth() const {
    return month;
}

int CDate::getYear() const {
    return year;
}

void CDate::setDay(int d) {
    day = d;
}

void CDate::setMonth(int m) {
    month = m;
}

void CDate::setYear(int y) {
    year = y;
}

CDate CDate::operator+(int days) const {
    CDate result = *this;
    // Add days to the current date
    // (Implementation omitted for brevity)
    return result;
}

CDate CDate::operator-(int days) const {
    CDate result = *this;
    // Subtract days from the current date
    // (Implementation omitted for brevity)
    return result;
}

CDate& CDate::operator++() {
    // Increment the current date by one day
    // (Implementation omitted for brevity)
    return *this;
}

CDate CDate::operator++(int) {
    CDate result = *this;
    ++(*this);  // Call the prefix increment operator
    return result;
}

CDate& CDate::operator--() {
    // Decrement the current date by one day
    // (Implementation omitted for brevity)
    return *this;
}

CDate CDate::operator--(int) {
    CDate result = *this;
    --(*this);  // Call the prefix decrement operator
    return result;
}

int CDate::operator-(const CDate& other) const {
    // Calculate the difference between two dates in days
    // (Implementation omitted for brevity)
    return 0;  // Placeholder value, implement your logic
}

std::ostream& operator<<(std::ostream& out, const CDate& date) {
    out << date.day << "/" << date.month << "/" << date.year;
    return out;
}

std::istream& operator>>(std::istream& in, CDate& date) {
    in >> date.day;
    in.ignore();  // Ignore the delimiter
    in >> date.month;
    in.ignore();
in >> date.year;
return in;
}
