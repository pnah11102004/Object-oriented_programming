#include "CString.h"
#include <cstring>

// Default constructor
CString::CString() {
    m_data = new char[1];
    m_data[0] = '\0'; // Empty string
}

// Constructor with a C-style string parameter
CString::CString(const char* str) {
    int length = strlen(str);
    m_data = new char[length + 1];
    strcpy(m_data, str);
}

// Copy constructor
CString::CString(const CString& other) {
    int length = other.GetLength();
    m_data = new char[length + 1];
    strcpy(m_data, other.GetString());
}

// Destructor
CString::~CString() {
    delete[] m_data;
}

// Get the length of the string
int CString::GetLength() const {
    return strlen(m_data);
}

// Get the C-style string representation
const char* CString::GetString() const {
    return m_data;
}

// Assignment operator
CString& CString::operator=(const CString& other) {
    if (this != &other) {
        delete[] m_data; // Free the previously allocated memory
        int length = other.GetLength();
        m_data = new char[length + 1];
        strcpy(m_data, other.GetString());
    }
    return *this;
}

// Concatenation operator
CString CString::operator+(const CString& other) const {
    int length1 = GetLength();
    int length2 = other.GetLength();
    char* result = new char[length1 + length2 + 1];
    strcpy(result, m_data);
    strcat(result, other.GetString());
    CString concatenatedString(result);
    delete[] result;
    return concatenatedString;
}

// Equality operator
bool CString::operator==(const CString& other) const {
    return strcmp(m_data, other.GetString()) == 0;
}

// Inequality operator
bool CString::operator!=(const CString& other) const {
    return strcmp(m_data, other.GetString()) != 0;
}
