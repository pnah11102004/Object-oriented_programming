#include <iostream>
#include "B7.h"
using namespace std;

int main()
{ std::vector<double> coefficients1 = {2, -3, 1}; // 2x^2 - 3x + 1
    Polynomial poly1(coefficients1, 2);

    std::vector<double> coefficients2 = {1, 2}; // x + 2
    Polynomial poly2(coefficients2, 1);

    // Perform operations on polynomials
    Polynomial sum = poly1;
    sum.add(poly2);

    Polynomial difference = poly1;
    difference.subtract(poly2);

    Polynomial product = poly1;
    product.multiply(poly2);

    Polynomial derivative = poly1.derivative();

    Polynomial integral = poly1.integral();

    // Print the results
    std::cout << "Polynomial 1: ";
    poly1.print();

    std::cout << "Polynomial 2: ";
    poly2.print();

    std::cout << "Sum: ";
    sum.print();

    std::cout << "Difference: ";
    difference.print();

    std::cout << "Product: ";
    product.print();

    std::cout << "Derivative: ";
    derivative.print();

    std::cout << "Integral: ";
    integral.print();

    return 0;
}
