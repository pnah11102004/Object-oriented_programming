#include "B7.h"
#include <iostream>

Polynomial::Polynomial() {
    degree = 0;
}

Polynomial::Polynomial(const std::vector<double>& coeffs, int deg) {
    coefficients = coeffs;
    degree = deg;
}

void Polynomial::setCoefficient(int deg, double coeff) {
    if (deg < 0 || deg > degree) {
        std::cout << "Invalid degree!" << std::endl;
        return;
    }
    coefficients[deg] = coeff;
}

double Polynomial::getCoefficient(int deg) const {
    if (deg < 0 || deg > degree) {
        std::cout << "Invalid degree!" << std::endl;
        return 0.0;
    }
    return coefficients[deg];
}

int Polynomial::getDegree() const {
    return degree;
}

void Polynomial::add(const Polynomial& other) {
    if (degree != other.degree) {
        std::cout << "Cannot add polynomials with different degrees!" << std::endl;
        return;
    }

    for (int i = 0; i <= degree; i++) {
        coefficients[i] += other.coefficients[i];
    }
}

void Polynomial::subtract(const Polynomial& other) {
    if (degree != other.degree) {
        std::cout << "Cannot subtract polynomials with different degrees!" << std::endl;
        return;
    }

    for (int i = 0; i <= degree; i++) {
        coefficients[i] -= other.coefficients[i];
    }
}

void Polynomial::multiply(const Polynomial& other) {
    std::vector<double> resultCoefficients(degree + other.degree + 1, 0.0);

    for (int i = 0; i <= degree; i++) {
        for (int j = 0; j <= other.degree; j++) {
            resultCoefficients[i + j] += coefficients[i] * other.coefficients[j];
}
}
coefficients = resultCoefficients;
degree = degree + other.degree;
}

void Polynomial::divide(const Polynomial& other) {
// Implement polynomial division logic here
// ...
}

Polynomial Polynomial::derivative() const {
std::vector<double> resultCoefficients(degree, 0.0);
for (int i = 1; i <= degree; i++) {
    resultCoefficients[i - 1] = coefficients[i] * i;
}

Polynomial derivative(resultCoefficients, degree - 1);
return derivative;
}

Polynomial Polynomial::integral() const {
std::vector<double> resultCoefficients(degree + 2, 0.0);
for (int i = 0; i <= degree; i++) {
    resultCoefficients[i + 1] = coefficients[i] / (i + 1);
}

Polynomial integral(resultCoefficients, degree + 1);
return integral;
}

void Polynomial::print() const {
for (int i = degree; i >= 0; i--) {
std::cout << coefficients[i] << "x^" << i;
if (i > 0) {
std::cout << " + ";
}
}
std::cout << std::endl;
}
