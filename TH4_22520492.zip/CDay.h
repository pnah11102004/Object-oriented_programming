#ifndef CDAY_H_INCLUDED
#define CDAY_H_INCLUDED


#include <iostream>

class CDate {
private:
    int day;
    int month;
    int year;

public:
    CDate();
    CDate(int d, int m, int y);

    int getDay() const;
    int getMonth() const;
    int getYear() const;

    void setDay(int d);
    void setMonth(int m);
    void setYear(int y);

    CDate operator+(int days) const;
    CDate operator-(int days) const;
    CDate& operator++();
    CDate operator++(int);
    CDate& operator--();
    CDate operator--(int);
    int operator-(const CDate& other) const;

    friend std::ostream& operator<<(std::ostream& out, const CDate& date);
    friend std::istream& operator>>(std::istream& in, CDate& date);
};



#endif // CDAY_H_INCLUDED
