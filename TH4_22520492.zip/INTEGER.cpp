#include <iostream>
#include "INTEGER.h"

int main() {
    INTEGER a(5);
    INTEGER b(3);

    INTEGER c = a + b;
    std::cout << "a + b = " << c.getValue() << std::endl;

    INTEGER d = a - b;
    std::cout << "a - b = " << d.getValue() << std::endl;

    INTEGER e = a * b;
    std::cout << "a * b = " << e.getValue() << std::endl;

    INTEGER f = a / b;
    std::cout << "a / b = " << f.getValue() << std::endl;

    INTEGER g = a % b;
    std::cout << "a % b = " << g.getValue() << std::endl;

    INTEGER h;
    h = a;
    std::cout << "h = " << h.getValue() << std::endl;

    return 0;
}
