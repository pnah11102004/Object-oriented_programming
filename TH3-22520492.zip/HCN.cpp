#include "HCN.h"

HCN::HCN() {
xA=yA=xB=yB=0;
}
HCN::HCN(double xA,double yA,double xB,double yB) {
    set(xA,yA,xB,yB);
}
void HCN::set(double xA, double yA, double xB, double yB) {
    this->xA = xA;
    this->yA = yA;
    this->xB = xB;
    this->yB = yB;
}
double HCN::getxA() {
    return xA;
}

double HCN::getyA() {
    return yA;
}

double HCN::getxB() {
    return xB;
}

double HCN::getyB() {
    return yB;
}
bool HCN::kiemTraHopLe() {
    return (xA != xB) && (yA != yB);
}
double HCN::tinhChuVi() {
    double a = fabs(xA - xB);
    double b = fabs(yA - yB);
    return 2 * (a + b);
}

double HCN::tinhDienTich() {
    double a = fabs(xA - xB);
    double b = fabs(yA - yB);
    return a * b;
}
void HCN::diChuyen(double dx, double dy) {
    xA += dx;
    yA += dy;
    xB += dx;
    yB += dy;
}
istream& operator >> (istream& is, HCN& hcn) {
    cout<<"Nhap toa do diem A(x,y): ";
    is>>hcn.xA>>hcn.yA;
    cout << "Nhap toa do diem B(x, y): ";
    is >> hcn.xB >> hcn.yB;
    return is;
}
ostream& operator << (ostream& os, const HCN& hcn) {
    os << "Hinh chu nhat co toa do 2 dinh la A(" << hcn.xA << ", " << hcn.yA << ") va B(" << hcn.xB << ", " << hcn.yB << ")" << endl;
}
