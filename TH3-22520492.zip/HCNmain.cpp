#include "HCN.h"


using namespace std;

int main()
{
    HCN hcn;
    cin>>hcn;
    if(!hcn.kiemTraHopLe())
    {
        cout<<"Hinh chu nhat khong hop le. "<<endl;
    }
    else {
    cout<<hcn;
    cout<<"Chu vi: "<<hcn.tinhChuVi()<<endl;
    cout<<"Dien tich: "<<hcn.tinhDienTich()<<endl;
    hcn.diChuyen(2,3);
    cout<<"Toa do hinh chu nhat sau khi di chuyen (2,3) : "<<hcn<<endl;
    }
    return 0;
}
