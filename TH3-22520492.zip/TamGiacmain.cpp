#include <iostream>
#include "TAMGIAC.h"

using namespace std;

int main() {
TAMGIAC tg;
// Nhập thông tin tam giác
cin >> tg;

// Hiển thị thông tin tam giác
cout << tg;

// Di chuyển tam giác
tg.diChuyen(1, 1);

// Hiển thị lại thông tin tam giác sau khi di chuyển
cout << tg;

// Tính chu vi và diện tích
if (tg.hopLe()) {
    cout << "Chu vi tam giac: " << tg.chuVi() << endl;
    cout << "Dien tich tam giac: " << tg.dienTich() << endl;
    cout << "Phan loai tam giac: " << tg.phanLoai() << endl;
}
else {
    cout << "Tam giac khong hop le!" << endl;
}

return 0;
}
