#ifndef HCN_H_INCLUDED
#define HCN_H_INCLUDED
#include <iostream>
#include <cmath>
using namespace std;

class HCN {
private:
    double xA,yA,xB,yB;
public:
    HCN();
    HCN(double xA, double yA,double xB, double yB);
    void set(double xA, double yA,double xB, double yB);
    double getxA();
    double getyA();
    double getxB();
    double getyB();
    bool kiemTraHopLe();
    double tinhChuVi();
    double tinhDienTich();
    void diChuyen(double dx, double dy);
    friend istream& operator >> (istream& is,HCN& hcn);
    friend ostream& operator << (ostream& os, const HCN&);
};

#endif // HCN_H_INCLUDED
