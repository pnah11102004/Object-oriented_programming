#pragma once
#ifndef _HinhTron
#define _HinhTron
#include "Diem.h"
class HTRON
{
private:
	DIEM O;
	double R;
	static int dem;
public:
	~HTRON();
	HTRON(double = 0, double = 0, double = 1);
	HTRON(DIEM, double = 1);
	void SetO(DIEM);
	void SetR(double);
	void SetHtron(DIEM, double);
	DIEM GetO() const;
	double GetR() const;
	static int GetDem();
	void DiChuyen(double, double);
	double TinhChuVi() const;
	double TinhDienTich() const;
	friend istream& operator>>(istream&, HTRON&);
	friend ostream& operator<<(ostream&,const HTRON&);
};

#endif // !_HinhTron

