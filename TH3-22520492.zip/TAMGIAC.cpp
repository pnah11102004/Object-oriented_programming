
#include "TAMGIAC.h"

TAMGIAC::TAMGIAC() {
    a_x = a_y = b_x = b_y = c_x = c_y = 0;
}

TAMGIAC::TAMGIAC(double ax, double ay, double bx, double by, double cx, double cy) {
    a_x = ax;
    a_y = ay;
    b_x = bx;
    b_y = by;
    c_x = cx;
    c_y = cy;
}

void TAMGIAC::setA(double x, double y) {
    a_x = x;
    a_y = y;
}

void TAMGIAC::setB(double x, double y) {
    b_x = x;
    b_y = y;
}

void TAMGIAC::setC(double x, double y) {
    c_x = x;
    c_y = y;
}

double TAMGIAC::getA_x() {
    return a_x;
}

double TAMGIAC::getA_y() {
    return a_y;
}

double TAMGIAC::getB_x() {
    return b_x;
}

double TAMGIAC::getB_y() {
    return b_y;
}

double TAMGIAC::getC_x() {
    return c_x;
}

double TAMGIAC::getC_y() {
    return c_y;
}

void TAMGIAC::nhap() {
    cout << "Nhap toa do diem A: ";
    cin >> a_x >> a_y;
    cout << "Nhap toa do diem B: ";
    cin >> b_x >> b_y;
    cout << "Nhap toa do diem C: ";
    cin >> c_x >> c_y;
}

void TAMGIAC::xuat() {
    cout << "Toa do diem A: (" << a_x << ", " << a_y << ")" << endl;
    cout << "Toa do diem B: (" << b_x << ", " << b_y << ")" << endl;
    cout << "Toa do diem C: (" << c_x << ", " << c_y << ")" << endl;
}

double TAMGIAC::chuVi() {
    double ab = sqrt(pow(b_x - a_x, 2) + pow(b_y - a_y, 2));
    double bc = sqrt(pow(c_x - b_x, 2) + pow(c_y - b_y, 2));
    double ac = sqrt(pow(c_x - a_x, 2) + pow(c_y - a_y, 2));
    return ab + bc + ac;
}
double TAMGIAC::dienTich() {
double ab = sqrt(pow(b_x - a_x, 2) + pow(b_y - a_y, 2));
double bc = sqrt(pow(c_x - b_x, 2) + pow(c_y - b_y, 2));
double ac = sqrt(pow(c_x - a_x, 2) + pow(c_y - a_y, 2));
double p = (ab + bc + ac) / 2;
return sqrt(p * (p - ab) * (p - bc) * (p - ac));
}

bool TAMGIAC::hopLe() {
double ab = sqrt(pow(b_x - a_x, 2) + pow(b_y - a_y, 2));
double bc = sqrt(pow(c_x - b_x, 2) + pow(c_y - b_y, 2));
double ac = sqrt(pow(c_x - a_x, 2) + pow(c_y - a_y, 2));
if (ab + bc > ac && ab + ac > bc && ac + bc > ab) {
return true;
}
return false;
}

string TAMGIAC::phanLoai() {
double ab = sqrt(pow(b_x - a_x, 2) + pow(b_y - a_y, 2));
double bc = sqrt(pow(c_x - b_x, 2) + pow(c_y - b_y, 2));
double ac = sqrt(pow(c_x - a_x, 2) + pow(c_y - a_y, 2));
if (ab == bc && ab == ac) {
return "Tam giac deu";
}
else if (ab == bc || ab == ac || bc == ac) {
return "Tam giac can";
}
else {
return "Tam giac thuong";
}
}

void TAMGIAC::diChuyen(double dx, double dy) {
a_x += dx;
b_x += dx;
c_x += dx;
a_y += dy;
b_y += dy;
c_y += dy;
}

istream& operator >> (istream& is, TAMGIAC& tg) {
cout << "Nhap toa do diem A: ";
is >> tg.a_x >> tg.a_y;
cout << "Nhap toa do diem B: ";
is >> tg.b_x >> tg.b_y;
cout << "Nhap toa do diem C: ";
is >> tg.c_x >> tg.c_y;
return is;
}

ostream& operator << (ostream& os, TAMGIAC& tg) {
os << "Toa do diem A: (" << tg.a_x << ", " << tg.a_y << ")" << endl;
os << "Toa do diem B: (" << tg.b_x << ", " << tg.b_y << ")" << endl;
os << "Toa do diem C: (" << tg.c_x << ", " << tg.c_y << ")" << endl;
return os;
}
