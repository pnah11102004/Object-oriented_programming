#include "HinhTron.h"
#define PI atan(1)*4
int HTRON::dem = 0;

HTRON::~HTRON()
{
	cout << "Huy HTRON\n";
	dem--;
}
HTRON::HTRON(double x, double y, double R) : O(x, y)
{
	SetR(R);
	dem++;
}
HTRON::HTRON(DIEM O, double R)
{
	SetR(R);
	dem++;
}
void HTRON::SetO(DIEM O)
{
	this->O = O;
}
void HTRON::SetR(double R)
{
	while (R <= 0)
	{
		cout << "Ban kinh khong hop le! Hay nhap lai! (R>0) ";
		cin >> R;
	}
	this->R = R;
}
void HTRON::SetHtron(DIEM O, double R)
{
	SetO(O);
	SetR(R);
}
DIEM HTRON::GetO() const
{
	return O;
}

double HTRON::GetR() const
{
	return R;
}
int HTRON::GetDem()
{
	return dem;
}
void HTRON::DiChuyen(double dx, double dy)
{
	O.DiChuyen(dx, dy);
}
double HTRON::TinhChuVi() const
{
	return 2 * PI * R;
}
double HTRON::TinhDienTich() const
{
	return PI * R * R;
}
istream& operator>>(istream& is, HTRON& htron)
{
	cout << "Nhap toa do tam O: \n";
	is >> htron.O;
	do
	{
		cout << "Nhap ban kinh R>0: ";
		is >> htron.R;
	} while (htron.R <= 0);
	return is;
}
ostream& operator<<(ostream& os, const HTRON& htron)
{
	os << "Htron tam O" << htron.O << ", ban kinh R = " << htron.R << " => Chu vi = " << htron.TinhChuVi() << ", Dien tich = " << htron.TinhDienTich() << endl;
	return os;
}


