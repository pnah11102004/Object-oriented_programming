#ifndef TAMGIAC_H_INCLUDED
#define TAMGIAC_H_INCLUDED


#include<iostream>
#include<math.h>

using namespace std;

class TAMGIAC {
private:
    double a_x, a_y, b_x, b_y, c_x, c_y;

public:
    TAMGIAC();
    TAMGIAC(double, double, double, double, double, double);

    void setA(double, double);
    void setB(double, double);
    void setC(double, double);

    double getA_x();
    double getA_y();
    double getB_x();
    double getB_y();
    double getC_x();
    double getC_y();

    void nhap();
    void xuat();

    double chuVi();
    double dienTich();
    bool hopLe();
    string phanLoai();

    void diChuyen(double, double);

    friend istream& operator >> (istream&, TAMGIAC&);
    friend ostream& operator << (ostream&, TAMGIAC&);
};

#endif
