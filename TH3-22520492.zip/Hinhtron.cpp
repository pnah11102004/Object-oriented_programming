#include"HinhTron.h"
int main()
{
	cout << "So hinh tron hien tai la: " << HTRON::GetDem() << endl;
	HTRON ht1, ht2(DIEM(1, 2), 3), * ht3 = new HTRON;
	cout << "So hinh tron hien tai la: " << HTRON::GetDem() << endl;
	cout << ht1 << ht2 << *ht3 << endl;
	cout << "Nhap lai hinh tron 3:\n";
	cin >> *ht3;
	cout << "Hinh tron 3 moi la: " << *ht3 << endl;
	ht3->DiChuyen(-1,1);
	cout << "Hinh tron 3 sau khi di chuyen (-1,1) la: " << *ht3 << endl;
	delete ht3;
	cout << "So hinh tron hien tai la:" << HTRON::GetDem() << endl;
	system("pause");
	return 0;


}